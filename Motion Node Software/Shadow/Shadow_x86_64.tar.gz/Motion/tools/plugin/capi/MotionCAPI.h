/**
  @file    MotionCAPI.h
  @version 2.0

  (C) Copyright Motion Workshop 2013. All rights reserved.

  The coded instructions, statements, computer programs, and/or related
  material (collectively the "Data") in these files contain unpublished
  information proprietary to Motion Workshop, which is protected by
  US federal copyright law and by international treaties.

  The Data may not be disclosed or distributed to third parties, in whole
  or in part, without the prior written consent of Motion Workshop.

  The Data is provided "as is" without express or implied warranty, and
  with no claim as to its suitability for any purpose.
*/
#ifndef __MNCAPI_H_
#define __MNCAPI_H_

#if !defined(MNCAPI_IMPORT_API)
#  if defined(_WIN32)
#    define MNCAPI_IMPORT_API __declspec(dllimport)
#  else
#    define MNCAPI_IMPORT_API
#  endif /* _WIN32 */
#endif /* MNCAPI_IMPORT_API */

#if !defined(MNCAPI_CALL_API)
#  if defined(_WIN32)
#    define MNCAPI_CALL_API __cdecl
#  else
#    define MNCAPI_CALL_API
#  endif /* _WIN32 */
#endif /* MNCAPI_CALL_API */

#ifdef __cplusplus
extern "C" {
#endif

#define MNCAPI_PREVIEW_SIZE (14)
#define MNCAPI_SENSOR_SIZE   (9)
#define MNCAPI_RAW_SIZE      (9)

enum mncapi_error_t {
  MNCAPI_FAILURE =  0,
  MNCAPI_SUCCESS =  1
};

enum mncapi_stream_t {
  MNCAPI_PREVIEW =  1,
  MNCAPI_SENSOR  =  2,
  MNCAPI_RAW     =  3
};

enum mncapi_blocking_t {
  MNCAPI_NOBLOCK = -1,
  MNCAPI_FOREVER =  0,
  MNCAPI_DEFAULT =  1
};

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_open(enum mncapi_stream_t type);

MNCAPI_IMPORT_API
void MNCAPI_CALL_API
mncapi_close(int handle);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_set_blocking(int handle,
                    int second);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_sample(int handle,
              float *data,
              int data_size);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_sample_int16(int handle,
                    short *data,
                    int data_size);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_get_preview(float *data);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_get_sensor(float *data);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_get_raw(short *data);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_open_host(enum mncapi_stream_t type,
                 const char *host,
                 int port);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_open_configurable(const char *xml,
                         const char *host,
                         int port);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_lua_chunk(const char *input,
                 char *output,
                 int output_size);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_lua_chunk_host(const char *host,
                      const char *input,
                      char *output,
                      int output_size);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_set_buffered(int handle,
                    int num);

MNCAPI_IMPORT_API
int MNCAPI_CALL_API
mncapi_sample_ready(int handle);

#ifdef __cplusplus
}
#endif

#endif /* __MNCAPI_H_ */
