#!/bin/sh
#
# External program suitable for running from a udev rule. The example rule
# will run when a MotionNode USB sensor is plugged into the system. The script
# below uses the Lua console to scan for devices and start them up.
#
# Example rule:
#
# SUBSYSTEMS=="usb", DRIVERS=="cp2101", RUN+="/opt/Motion/tools/linux/udev_run_rule.sh"
#
# Create a file that your udev system will read as a rule. An example path is:
#
# /etc/udev/rules.d/85-motion.rules
#
# The 85 prefix indicates a rule ordering, indicating a rule that runs an
# application.
#
#
# @file    tools/linux/udev_run_rule.sh
# @version 2.0
#

CMD="/opt/Motion/MotionService --console"

if [ "add" = "$ACTION" ] ; then
  echo "node.close() node.erase() node.scan() if node.is_configured() then node.start() end" | $CMD
elif [ "remove" = "$ACTION" ] ; then
  echo "node.close() node.erase() node.scan() if node.is_configured() then node.start() end" | $CMD
fi
