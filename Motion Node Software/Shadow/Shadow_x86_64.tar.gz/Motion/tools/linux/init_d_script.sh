#!/bin/sh
#
# Example system boot script for the Motion Service. Start the
# daemon at run level load time.
#
# Copy this file to where your boot scripts reside. For example:
#
#   cp init_d_script.sh /etc/init.d/Motion
#
# Add the script to some run level startups. For example:
#
#   update-rc.d Motion defaults
#
# To disable the startup script run the following command:
#
#   update-rc.d Motion remove
#
#
# @file    tools/linux/init_d_script.sh
# @version 2.0
#

#
# Change this to the user account you would like to run the
# Motion Service under. Optionally supply as a variable
# in the environment.
#
if [ "$MOTION_USER" == "" ]; then
  MOTION_USER=root
fi

#
# Change this to your actual install path. Optionally supply
# as a variable in the environment.
#
if [ "$MOTION_PATH" == "" ]; then
  MOTION_PATH=/opt/Motion
fi

#
# Data folder. Specify the full path. This takes precedence over
# the user home folder and the MOTIONNODE_HOME environment variable.
#
export MOTION_DATA=/home/$MOTION_USER/Motion

#
# Home directory where the data folder resides. The data folder
# is named Motion and is a subfolder. This takes precedence
# over the standard HOME environment variable.
#
export MOTION_HOME=/home/$MOTION_USER

#
# Full path to the daemon.
#
MOTION_DAEMON=$MOTION_PATH/MotionService


do_start() {
  if [ -x $MOTION_DAEMON ]; then
    if [ -x start-stop-daemon ]; then
      start-stop-daemon --start -- --quiet \
        --chuid $MOTION_USER \
        --exec $MOTION_DAEMON
    else
      su $MOTION_USER -c $MOTION_DAEMON --quiet
    fi
  fi
}

do_stop() {
  if [ -x $MOTION_DAEMON ]; then
    if [ -x start-stop-daemon ]; then
      start-stop-daemon --stop -- --quiet \
        --chuid $MOTIONNODE_USER \
        --exec $MOTION_DAEMON
    elif [ "$MOTIONNODE_USER" == "root" ]; then
      echo "node.system.quit()" | $(MOTION_DAEMON) --console
    else
      su $MOTION_USER -c "echo \"node.system.quit()\" | $MOTION_DAEMON --console"
    fi
  fi
}

case "$1" in
  start)
    do_start
    ;;
  restart|reload|force-reload)
    echo "Error: argument '$1' not supported" >&2
    exit 3
    ;;
  stop)
    do_stop
    ;;
  *)
   echo "Usage: $0 start|stop" >&2
   exit 3
   ;;
esac
