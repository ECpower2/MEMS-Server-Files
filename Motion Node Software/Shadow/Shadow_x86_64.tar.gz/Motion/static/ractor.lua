--
-- Return an string XML description of the active ractor definition in the
-- Motion Service.
--
-- @file    static/ractor.lua
-- @version 2.0
--

local node_name = "ractor"

-- Utility function. Generate a location XML snippet based on input parameters.
local function ractor_node_to_xml(name, height, arm, leg, active, key)
  local result = "<definition"
  if key then
    result = result .. " key=\"" .. node.xml.encode_attribute(key) .. "\""
  end
  if active then
    result = result .. " active=\"" .. node.xml.encode_attribute(active) .. "\""
  end
  
  result = result .. ">"
  
  if name then
    result = result .. "<name>" .. node.xml.encode_string(name) .. "</name>"
  end
  
  result = result ..
    "<measurement unit=\"cm\">" ..
    "<height>" .. node.xml.encode_string(height) .. "</height>" ..
    "<arm>" .. node.xml.encode_string(arm) .. "</arm>" ..
    "<leg>" .. node.xml.encode_string(leg) .. "</leg>" ..
    "</measurement>"

  result = result .. "</definition>"

  return result
end

local result =
  "<?xml version=\"1.0\"?>" ..
  "<" .. node_name .. ">"

local list = node.system.get_ractor_list()
if list then
  for _,item in ipairs(list:list()) do
    result = result .. ractor_node_to_xml(item.name, item.height, item.arm, item.leg, item.active, item.key)
  end
else
  local preference = node.system.get_preference()
  if preference then
    result = result .. ractor_node_to_xml(preference.ractor_name, preference.height, preference.arm, preference.leg, 1, null)
  end
end

result = result .. "</" .. node_name .. ">"

return result
