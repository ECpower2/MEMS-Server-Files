--
-- Return a string JSON description of the current configuration list of the
-- Motion Service. Show all hardware devices that are available and their
-- current status.
--
-- @file    json/settings.lua
-- @version 2.2
--
local base = _G

local is_taking = node.is_taking()
local is_reading = is_taking or node.is_reading()
local is_connected = is_reading or node.is_connected()
local is_configured = is_connected or node.is_configured()
local is_tracking = node.is_tracking()

local state = {
  ['is_configured'] = is_configured,
  ['is_connected'] = is_connected,
  ['is_reading'] = is_reading,
  ['is_taking'] = is_taking,
  ['is_tracking'] = is_tracking,
  ['node'] = {}
}

local _node_to_json
_node_to_json = function(configured_node, default_node, is_connected, is_reading, detail)
  local show_detail = false
  if detail and configured_node.id == detail then
    show_detail = true
  end
    
  local state = {
    ['key'] = configured_node.key,
    ['id'] = configured_node.id,
    ['name'] = configured_node.name,
    ['source'] = configured_node.source,
    ['gain'] = configured_node.gain,
    ['gselect'] = configured_node.gselect,
    ['gain_sensor'] = configured_node.gain_sensor,
    ['track_gyroscope_bias'] = configured_node.track_gyroscope_bias,
    ['pipeline_select'] = configured_node.pipeline_select,
    ['is_connected'] = is_connected or node.is_connected(configured_node.id),
    ['is_reading'] = is_reading or node.is_reading(configured_node.id),
    ['node'] = {}
  }

  local optional = {
    'active',
    'bus',
    'delay',
    'gain',
    'gain_sensor',
    'node_version',
    'parent',
    'pipeline_select',
    'sample_rate',
    'track_gyroscope_bias',
    'uuid'
  }

  for _,field in pairs(optional) do
    if show_detail or configured_node[field] ~= default_node[field] then
      state[field] = configured_node[field]
    end
  end

  return state
end

local _tree_to_json
_tree_to_json = function(configured_node, default_node, is_connected, is_reading, detail)
  local result = _node_to_json(
    configured_node.value, default_node, is_connected, is_reading, detail)
    
  for _,child_node in pairs(configured_node:list()) do
    table.insert(
      result.node,
      _tree_to_json(child_node, default_node, is_connected, is_reading, detail))
  end

  return result
end

if true then
  --
  -- Node list.
  --
  local configured_node = node.configuration()
  if configured_node then
    local default_node = node.get_node_default()
    for _,child_node in pairs(configured_node:list()) do
      local node_state = _node_to_json(
        child_node, default_node, is_connected, is_reading, node_detail)
      if node_state then
        table.insert(state.node, node_state)
      end     
    end    
  end
else
  --
  -- Node tree.
  --
  local configured_node = node.configuration_tree()
  if configured_node then
    local default_node = node.get_node_default()
    for _,child_node in pairs(configured_node:list()) do
      local node_state = _tree_to_json(
        child_node, default_node, is_connected, is_reading, node_detail)
      if node_state then
        table.insert(state.node, node_state)
      end     
    end
  end
end

return node.json.encode(state)
