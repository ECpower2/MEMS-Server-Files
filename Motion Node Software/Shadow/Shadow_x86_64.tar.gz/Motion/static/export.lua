--
-- Return an string XML description of the current export options for the
-- Motion Service.
--
-- @file    static/export.lua
-- @author  Luke Tokheim, luke@motionnode.com
-- @version 2.0
--

local result =
  "<?xml version=\"1.0\"?>" ..
  "<export"
  
local preference = node.system.get_preference()
if preference then
  result = result .. " data_path=\"" .. node.xml.encode_string(preference.data_path) .. "\""
end
result = result .. ">"

local export_type = node.system.export_type()
if export_type then
  result = result .. "<format_list"
  select_type = node.system.export_default_type()
  if select_type then
    result = result .. " default=\"" .. node.xml.encode_string(select_type) .. "\""
  end
  result = result .. ">"
  for key,value in pairs(export_type) do
    result = result ..
      "<format>" ..
      "<type>" .. node.xml.encode_string(key) ..  "</type>" ..
      "<description>" .. node.xml.encode_string(value.description) ..  "</description>" ..
      "<option>" .. node.xml.encode_string(value.option) ..  "</option>" ..
      "</format>"
  end
  result = result .. "</format_list>"
end

result = result ..
  node.xml.take_to_xml() ..
  node.xml.history_to_xml() ..
  "</export>"

return result