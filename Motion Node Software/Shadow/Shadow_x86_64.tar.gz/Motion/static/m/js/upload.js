$(document).ready(function () {
  if (typeof window.FileReader === "undefined") {
    return;
  }

  jQuery.event.props.push("dataTransfer");

  $(this)
    .on("dragover", function (e) {
      e.stopPropagation();
      e.preventDefault();

      $("#upload").addClass("hl");

      return false;
    })
    .on("dragleave", function (e) {
      e.stopPropagation();
      e.preventDefault();

      $("#upload").removeClass("hl");

      return false;
    })
    .on("drop", function (e) {
      e.stopPropagation();
      e.preventDefault();

      $("#upload").addClass("hl");

      var files = e.dataTransfer.files;
      if ((null === files) || (undefined === files) || (0 === files.length)) {
        return false;
      }

      var file = e.dataTransfer.files[0];

      var reader = new FileReader();
      reader.onload = function (event) {
        $.post("/file.html", event.target.result, function (data) {
          GLI_Command.send("open", data);
        });
      };

      reader.readAsText(file, "UTF-8");

      return false;
    });
});