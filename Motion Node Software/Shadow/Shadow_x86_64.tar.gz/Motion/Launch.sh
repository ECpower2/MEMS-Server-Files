#!/bin/sh
#
# Launch script for the Motion system. Start the daemon if necessary and then
# start a web browser session with the default service address.
#
# @file    Launch.sh
# @author  Luke Tokheim, luke@motionnode.com
# @version 2.0
#

INSTALL_NAME=Motion
DAEMON_NAME=MotionService

if [ "$MOTION_HOME" != "" ]; then
  TARGET=$MOTION_HOME
else
  TARGET=$HOME
fi

#
# Option to turn off the Wireless Bus functionality.
#
#export MOTION_ENABLE_REMOTE_BUS=0


#
# Verify that the user data folder exists. If not, use the InitializeHome.sh
# script to create it for us.
#
if [ ! -d $TARGET ] || [ ! -d $TARGET/$INSTALL_NAME ] || [ ! -d $TARGET/$INSTALL_NAME/default ]; then
  if [ -x ./InitializeHome.sh ]; then
    ./InitializeHome.sh $TARGET
  else
    echo Failed to find \"InitializeHome.sh\" script in working directory
  fi
fi

#
# Check for a running instance of the daemon. Create a new one if none are
# running.
#
STARTED=0
RUNNING=`ps -ef | grep -v grep | grep $DAEMON_NAME | wc -l`;
if [ 0 -eq $RUNNING ]; then
  if [ -x ./$DAEMON_NAME ]; then
    echo Starting daemon with user data folder \"$TARGET\", using daemon log
    ./$DAEMON_NAME --quiet
    STARTED=1
  else
    echo Failed to find \"$DAEMON_NAME\" application in working directory
  fi
fi

#
# Launch the User Interface web address.
#
URL=http://127.0.0.1:32080/
LAUNCH=

# Wrapper around the which utility because it works differently
# on various platforms.
findbin()
{
  WHICH=`which $1 2>/dev/null`
  if [[ $? -eq 0 && "${WHICH}" != "" && -x ${WHICH} ]]; then
    echo "${WHICH}"
  fi

  return
}


if [ "$DISPLAY" != "" ]; then

  # Search for a URL launcher.
  for item in "gnome-open" "xdg-open" "gvfs-open" "kfmclient" "firefox"
  do
    LAUNCH=`findbin ${item}`
    if [ "${LAUNCH}" != "" ]; then
      break
    fi
  done

  if [ "$LAUNCH" != "" ]; then
    # If the daemon just launched, wait a second before
    # we launch the UI.
    if [ 1 -eq $STARTED ]; then
      sleep 1
    fi

    $LAUNCH $URL &>/dev/null
  else
    echo Failed to find web browser. Can not launch user interface at \"$URL\".
  fi
else
  echo No active display. Can not launch user interface at \"$URL\".
fi

