--
-- node.lua
--   Pure Lua library functions for the Motion Service software. Implements
--   higher level functions in terms of the Manager class interface.
--   Intended as the public scripting interface to the Motion Service.
--
--   See the "manual/Scripting API Reference.pdf" for a detailed reference.
--


--
-- Declare module and import dependencies.
--
local base = _G
local manager = base.manager
local math = require("math")
local string = require("string")
local table = require("table")

-- Package declaration. All following declarations are in this module table.
local node = {
  _COPYRIGHT = "Copyright 2015 Motion Workshop",
  _NAME = "Node",
  _DESCRIPTION = "Public scripting interface to the Motion device management service.",
  _VERSION = manager.version,
  _DEMO = manager.version_demo,
  _BUS = manager.version_bus,

  -- Default names for some files.
  _initialize_filename = "default/initialize.lua",
  _configuration_filename = "default/configuration.mNode",
  _location_filename = "default/location.mGeocode",
  _ractor_filename = "default/ractor.mRactor",
  _take_filename = "take.mTake"
}

-- Module local state variables.
local _initialized = false
local _history = {}
local _default_id = "default"
local _service = {}
local _NAME = node._NAME

-- Table of USB device related functions.
node.usb = {}
-- Table of Motion system initialization, configuration, and state functions. 
node.system = {}
-- Table of XML string processing related functions.
node.xml = {}
-- Table of JSON string processing related functions.
node.json = {}


--
-- Begin public function definitions.
--

function node.auto_connect(rescan)
  -- Always close active connections.
  if node.is_connected() then
    node.close()
  end

  -- If we are in full rescan mode, clear out the current configuration.
  if rescan and node.is_configured() then
    node.erase()
  end

  -- Scan for new hardware.
  node.scan()

  -- Start reading from all nodes in the configuration.
  return node.start()
end

function node.close(id)
  -- Only enforce is_connected(id) for single Node close.
  if id then
    if not node.is_connected(id) then
      return false, "failed precondition, \"is_connected(\"" .. id .. "\") == true\""
    end
  end

  -- Stop take.
  if node.is_taking() then
    local result, message = node.stop_take()
    if not result then
      return result, message
    end
  end

  -- Stop reading.
  if node.is_reading(id) then
    local result, message = node.stop(id)
    if not result then
      return result, message
    end
  end

  if id then
    if not manager:close(id) then
      return false, "failed to close connection to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    -- Do not call close if the configuration is empty.
    if not node.is_configured() then
      return false, "no configured " .. _NAME .. "s"
    end

    -- Do not call close if the connection list is empty.
    if not node.connected() then
      return false, "no connected " .. _NAME .. "s"
    end

    if not manager:close() then
      return false, "failed to close at least one open connection"
    end
  end

  return true, ""
end

function node.configuration()
  return manager:configuration()
end

function node.configuration_tree()
  return manager:configuration_tree()
end

function node.connect(id)
  if not node.is_configured(id) then
    if id then
      return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition \"is_configured() == true\""
    end
  end
  if node.is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end
  
  
  if id then
    if not manager:connect(id) then
      return false, "failed to connect to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    if not manager:connect() then
      return false, "failed to connect to at least one " .. _NAME .. " in configuration"
    end
  end
  
  return true, ""
end

function node.connected()
  return manager:connected()
end

function node.define_identity_pose()
  return node.set_pose()
end

function node.enumerate(name)
  if node.is_connected() then
    return nil
  end
  if node.connected() then
    return nil
  end

  if base.type(manager["enumerate"]) == base.type(function () end) then
    if name then
      return manager:enumerate(name)
    else
      return manager:enumerate()
    end
  else
    return nil
  end
end

function node.merge_configuration(name, tree_xml)
  if node.is_connected() then
    return false, "failed precondition, \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end

  if not name then
    name = ""
  end
  if not tree_xml then
    tree_xml = ""
  end

  if manager:merge_configuration(name, tree_xml) then
    return true, ""
  else
    return false, "failed to merge enumerated tree into configuration"
  end 
end

function node.erase(id)
  if not node.is_configured(id) then
    if id then
      return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition \"is_configured() == true\""
    end
  end
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if id then
    if not manager:erase(id) then
      return false, "failed to erase " .. _NAME .. " configuration with id \"" .. id .. "\""
    end
  else
    if not manager:erase() then
      return false, "failed to erase " .. _NAME .. " configuration"
    end
  end
  
  return true, ""
end

function node.export(filename, option, type)
  if not filename then
    filename = ""
  end

  _history["export"] = filename

  if not node.system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end
  if not node.have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not node.is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end
  if not node.system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end

  if not type or string.len(type) == 0 then
    _, _, type = string.find(filename, "%.([^%.]+)$")
  end
  
  if not type then
    type = node.system.export_default_type()
  end

  local valid_type = node.system.export_type()
  if not valid_type[type] then
    return false, "invalid export type \"" .. base.tostring(type) .. "\" for file \"" .. filename .. "\""
  else
    if not string.find(filename, "%." .. type .. "$") then
      filename = filename .. "." .. type
    end
  end

  -- Create a list of the default options for this file type. Every type inherits
  -- the same base set of options.
  if not option then
    if valid_type[type]["option"] and (string.len(valid_type[type]["option"]) > 0) then
      option = valid_type[type]["option"]
    else
      option = ""
    end
  end

  _history["export_type"] = type
  _history["export_option"] = option

  if not manager:export(filename, option, type) then
    return false, "failed to export take to file \"" .. filename .. "\""
  end
  
  _history["export"] = node.system.file_canonical(filename)

  return true, ""
end

function node.export_stream(filename, option, type)
  if not filename then
    filename = ""
  end

  _history["export_stream"] = filename

  if not node.system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end
  if not node.have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not node.is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end
  if not node.system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end
  
  if not type or string.len(type) == 0 then
    _, _, type = string.find(filename, "%.([^%.]+)$")
  end
  
  if not type then
    type = "csv"
  end

  local valid_type = node.system.export_stream_type()
  if not valid_type[type] then
    return false, "invalid export type \"" .. base.tostring(type) .. "\" for file \"" .. filename .. "\""
  else
    if not string.find(filename, "%." .. type .. "$") then
      filename = filename .. "." .. type
    end
  end 

  -- Create a list of the default options.
  if not option then
    if valid_type[type]["option"] and (string.len(valid_type[type]["option"]) > 0) then
      option = valid_type[type]["option"]
    else
      option = ""
    end
  end

  if not manager:export_stream(filename, option) then
    return false, "failed to export take stream to file \"" .. filename .. "\""
  end

  _history["export_stream"] = node.system.file_canonical(filename)

  return true, ""
end

function node.get_node(key, value, compare)
  if not compare then
    compare = function(lhs, rhs) return lhs == rhs end
  end

  if "id" == key and _default_id == value then
    return node.get_node_default()
  else
    local container = node.configuration()

    if container then
      local configured_node
      for _,configured_node in base.pairs(container:list()) do
        if compare(value, configured_node[key]) then
          return configured_node
        end
      end
    end
  end

  return nil
end

function node.get_node_by_id(id)
  return node.get_node("id", id)
end

function node.get_node_by_key(key)
  return node.get_node("key", key)
end

function node.get_node_default()
  return manager:get_node_default()
end

function node.get_preview()
  return manager:get_preview()
end

function node.get_raw()
  return manager:get_raw()
end

function node.get_sensor()
  return manager:get_sensor()
end

function node.get_data_path()
  local pref = node.system.get_preference()
  if pref then
    return true, pref.data_path
  else
    return false, ""
  end
end

function node.get_take_path()
  if node.have_take() then
    local t = node.take()
    local result, path = node.get_data_path()
    if t and result then
      if t.loaded_from and string.len(t.loaded_from) > 0 then
        return true, path .. "/" .. t.loaded_from
      else
        return true, path .. "/" .. t.name .. "/" .. node._take_filename
      end
    end
  end

  return false, ""
end

function node.have_take()
  return manager:have_take()
end

function node.insert(id)
  _history["insert"] = id

  if not node.is_id(id) then
    if not id then
      id = ""
    end
    return false, "failed precondition \"is_id(\"" .. id .. "\") == true\""
  end
  local result, id = node.system.unique_id(id)
  if not result then
    return false, "failed precondition \"system.unique_id(\"" .. id .. "\") == true\""
  end  
  if node.is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == false\""
  end  
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end

  if not manager:insert(id) then
    return false, "failed to insert " .. _NAME .. " configuration with id \"" .. id .. "\""
  end

  return true, id
end

function node.is_configured(id)
  if id then
    if id == _default_id then
      return true
    else
      return manager:is_configured(id)
    end
  else
    return manager:is_configured()
  end
end

function node.is_connected(id)
  if id then
    return manager:is_connected(id)
  else
    return manager:is_connected()
  end
end

function node.is_id(id)
  if id then
    return manager:is_id(id)
  else
    return false
  end
end

function node.is_reading(id)
  if id then
    return manager:is_reading(id)
  else
    return manager:is_reading()
  end
end

function node.is_taking()
  return manager:is_taking()
end

function node.is_tracking()
  return manager:is_tracking()
end

function node.load_configuration(filename)
  if not filename then
    filename = ""
  end

  _history["load_configuration"] = filename

  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end

  if not manager:load_configuration(filename) then
    return false, "failed to load configuration file \"" .. filename .. "\""
  end
  
  _history["load_configuration"] = node.system.file_canonical(filename)

  return true, ""
end

function node.load_location(filename)
  if not filename then
    filename = ""
  end

  _history["load_location"] = filename
  
  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if not manager:load_location(filename) then
    return false, "failed to load location file \"" .. filename .. "\""
  end
  
  _history["load_location"] = node.system.file_canonical(filename)

  return true, ""
end

function node.load_ractor(filename)
  if not filename then
    filename = ""
  end

  _history["load_ractor"] = filename
  
  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if not manager:load_ractor(filename) then
    return false, "failed to load ractor definition file \"" .. filename .. "\""
  end
  
  _history["load_ractor"] = node.system.file_canonical(filename)

  return true, ""
end

function node.load_script(filename)
  if not filename then
    filename = ""
  end

  _history["load_script"] = filename

  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end

  if not manager:load_script(filename) then
    return false, "failed to load script file \"" .. filename .. "\""
  end
  
  _history["load_script"] = node.system.file_canonical(filename)
  
  return true, ""
end

function node.load_take(filename)
  if not filename then
    filename = ""
  end

  _history["load_take"] = filename

  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end 

  if not manager:load_take(filename) then
    return false, "failed to load take file \"" .. filename .. "\""
  end
  
  _history["load_take"] = node.system.file_canonical(filename) 
  
  return true, ""
end

function node.load_take_source(filename)
  if filename then
    _history["load_take_source"] = filename
  
    local result, message = node.load_take(filename)
    if not result then
      return result, message
    end
    
    _history["load_take_source"] = node.system.file_canonical(filename)
  end

  if not node.have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not node.is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  if not node.system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end

  if not manager:load_take_source() then
    return false, "failed to load take as " .. _NAME .. " source"
  end

  return true, ""
end

function node.num_active(container, active)
  if container then
    if not active then
      return #container:list()
    else
      local num_node = 0
      local reading_node
      for _,reading_node in base.pairs(container:list()) do
        if not reading_node.bus and reading_node.active then
          num_node = num_node + 1
        end
      end
      
      return num_node
    end
  else
	  return 0
  end
end

function node.num_configured(active)
  return node.num_active(node.configuration(), active)
end

function node.num_connected(active)
  return node.num_active(node.connected(), active)
end

function node.num_reading(active)
  return node.num_active(node.reading(), active)
end

function node.open(filename)
  if not filename then
    filename = ""
  end

  _history["open"] = filename

  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end

  -- Automatically close active connections when we call file open.
  local reconnect = node.is_connected() and node.close()

  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end 

  if not manager:open(filename) then
    return false, "failed to open file \"" .. filename .. "\""
  end

  if reconnect then
    node.start()
  end
  
  _history["open"] = node.system.file_canonical(filename)

  return true, ""
end

function node.parent(id, parent_id)
  if node.is_connected() then
    return false, "failed precondition \"is_connected() == false\""
  end
  if not node.is_configured(id) then
    if id then
      return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
    else
      return false, "missing required id parameter"
    end
  end
  if not node.is_configured(parent_id) then
    if id then
      return false, "failed precondition \"is_configured(\"" .. parent_id .. "\") == true\""
    else
      return false, "missing required parent id parameter"
    end
  end
  
  return manager:parent(id, parent_id);
end

function node.reading()
  return manager:reading()
end

function node.read_user_data(id)
  if node.is_id(id) and base.type(manager["read_user_data"]) == base.type(function () end) then 
    return manager:read_user_data(id)
  else
    return nil
  end
end

function node.replay_take(filename)
  local take_name = filename

  if not filename and node.have_take() then
    local current_take = node.take()
    if current_take then
      take_name = current_take.name
    end
  end

  local result, message = node.load_take_source(filename)
  if not result then
    return result, message
  end

  local result, message = node.start_take("", "Replay of \"" .. take_name .. "\"")
  if not result then
    return result, message
  end

  return true, ""
end

function node.save_configuration(filename)
  if not filename then
    filename = ""
  end

  _history["save_configuration"] = filename

  if not node.system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename ..
                  "\") == true\""
  end
  if not node.is_configured() then
    return false, "failed precondition \"is_configured() == true\""
  end

  if not manager:save_configuration(filename) then
    return false, "failed to save configuration file \"" .. filename .. "\""
  end
  
  _history["save_configuration"] = node.system.file_canonical(filename)

  return true, ""
end

function node.scan(device_filter)
  if node.is_connected() then
    return false, "failed precondition, \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end

  local num_device = 0
  local num_device_existing = 0
  
  -- Run all device enumeration routines. Optionally only scan
  -- for devices of a specific class name.
  local enumeration = {}
  if device_filter then
    enumeration[device_filter] = node.enumerate(device_filter)
  else
    enumeration["all"] = node.enumerate()
  end

  -- Grab the current configuration list.
  local configured = node.configuration()
  local in_configuration = {}

  -- Create a table of existing hardware sources.
  if configured then
    local configured_node
    for _,configured_node in base.pairs(configured:list()) do
      in_configuration[configured_node.source] = true
    end
  end

  -- Iterate through each enumeration result and add the
  -- device to the configuration.
  for _,container in base.pairs(enumeration) do
    local parent_id = ""

    local enumerated_node
    for _,enumerated_node in base.pairs(container:list()) do
      if not in_configuration[enumerated_node.source] then
        -- Use the device name as the id if it is available. Otherwise
        -- fall back on the id field, which will be a cleaned version
        -- of the device address or identifier.
        local id = enumerated_node.name
        if not node.is_id(id) then
          id = enumerated_node.id
        end

        local result, id = node.system.unique_id(id)
        if result and not node.is_configured(id) then
          local is_bus = false
          if enumerated_node.bus then
            is_bus = true
            parent_id = ""
          elseif 0 == string.len(enumerated_node.parent) then
            parent_id = ""
          end

          local configured_node = manager:insert(id, is_bus, parent_id, enumerated_node.uuid)
          if configured_node then
            if #enumerated_node.name > 0 then
              configured_node.name = enumerated_node.name
            end
            configured_node.source = enumerated_node.source
            configured_node.gselect = enumerated_node.gselect
            if string.len(enumerated_node.parent) > 0 then
              configured_node.parent = parent_id
            else
              if is_bus then
                parent_id = id
              else
                parent_id = ""
              end
            end

            -- Load settings for this particular node.
            node.system.get_settings(id)

            num_device = num_device + 1
          else
            return false, "failed to insert " .. _NAME ..
                          " configuration with id \"" .. id .. "\""
          end
        end
      else
        num_device_existing = num_device_existing + 1
      end
    end
  end -- for each container

  -- Search for enumerated devices that have an associated tree structure.
  local container
  for _,container in base.pairs(enumeration) do
    local enumerated_node
    for _,enumerated_node in base.pairs(container:list()) do
      if enumerated_node.have_tree and not in_configuration[enumerated_node.source] then
        if node.merge_configuration(enumerated_node.source, enumerated_node.tree_xml) then
          in_configuration[enumerated_node.source] = true
        end
      end
    end
  end

  if 0 == num_device then
    if 0 == num_device_existing then
      return false, "no devices found"
    else
      return false, "no additional devices found"
    end
  end

  return true, ""
end

function node.set_configuration(key, value, id, ignore_children)
  if not node.is_configured(id) then
    if id then
      return false, "failed precondition, \"is_configured(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition, \"is_configured() == true\""
    end
  end

  local result = false
  
  if id then
    local configured_node = node.get_node_by_id(id)
    if configured_node then
      configured_node[key] = value
      result = true
    end

    -- Propagate change to any node that lists this as its parent.
    if not ignore_children then
      local container = node.configuration()
      if container then
        local configured_node
        for _,configured_node in base.pairs(container:list()) do
          if id == configured_node.parent then
            configured_node[key] = value
          end
        end
      end
    end
  else
    local container = node.configuration()
    if container then
      local configured_node
      for _,configured_node in base.pairs(container:list()) do
        configured_node[key] = value
        result = true
      end
    end
  end

  return result, ""
end

function node.set_gain(value, id)
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return node.set_configuration("gain", value, id)
end

function node.set_gain_sensor(value, id)
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return node.set_configuration("gain_sensor", value, id)
end

function node.set_gselect(value, id)
  if node.is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end

  return node.set_configuration("gselect", value, id)
end

function node.set_name(value, id)
  if node.is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end

  return node.set_configuration("name", value, id, true)
end

function node.set_pipeline_select(value, id)
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return node.set_configuration("pipeline_select", value, id)
end

function node.set_hierarchy(id, fn, rx, ry, rz, tx, ty, tz)
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  if not node.is_configured(id) then
    if id then
      return false, "failed precondition, \"is_configured(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition, \"is_configured() == true\""
    end
  end 

  if base.type(manager[fn]) == base.type(function () end) then

    if id then
      if (not(tx) and manager[fn](manager, id, rx, ry, rz)) or manager[fn](manager, id, rx, ry, rz, tx, ty, tz) then
      else
        return false, "failed to update hierarchy for " .. _NAME .. " id, \"" .. id .. "\""
      end
    else
      local container = node.configuration()
      if container then
        result = true

        local configured_node
        for _,configured_node in base.pairs(container:list()) do
          local id = configured_node.id
          if (not(tx) and manager[fn](manager, id, rx, ry, rz)) or manager[fn](manager, id, rx, ry, rz, tx, ty, tz) then
          else
            return false, "failed to update hierarchy for " .. _NAME .. " id, \"" .. id .. "\""
          end
        end
      end
    end

    return true, ""
  else
    return false, "hierarchy interface not implemented"
  end
end

function node.set_rotate(id, x, y, z)
  return node.set_hierarchy(id, "set_node_rotate", x, y, z)
end

function node.set_translate(id, x, y, z)
  return node.set_hierarchy(id, "set_node_translate", x, y, z)
end

function node.set_marker(id, x, y, z, tx, ty, tz)
  if not(tx) or not(ty) or not(tz) then
    tx = 0
    ty = 0
    tz = 0
  end

  return node.set_hierarchy(id, "set_node_marker", x, y, z, tx, ty, tz)
end

function node.set_offset(id, x, y, z, tx, ty, tz)
  if not(tx) or not(ty) or not(tz) then
    tx = 0
    ty = 0
    tz = 0
  end

  return node.set_hierarchy(id, "set_node_offset", x, y, z, tx, ty, tz)
end

function node.set_pose(id)
  if not node.is_reading() then
    return false, "failed precondition, \"is_reading() == true\""
  end
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end 
  
  if id then
    if not manager:set_pose(id) then
      return false, "failed to set zero pose for \"" .. id .. "\" subtree"
    end 
  else
    if not manager:set_pose() then
      return false, "failed to set zero pose for at least one configured " .. _NAME
    end
  end
  
  return true, ""
end

function node.set_pose_marker(id)
  if not node.is_reading() then
    return false, "failed precondition, \"is_reading() == true\""
  end
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  if id then
    if not manager:set_pose_marker(id) then
      return false, "failed to create rest pose orientation marker for \"" .. id .. "\" subtree"
    end
  else
    if not manager:set_pose_marker() then
      return false, "failed to create rest pose orientation marker for at least one configured " .. _NAME
    end
  end

  return true, ""
end

function node.set_track_gyroscope_bias(value, id)
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  return node.set_configuration("track_gyroscope_bias", value, id)
end

function node.set_source(value, id)
  if node.is_connected(id) then
    if id then
      return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_connected() == false\""
    end
  end

  return node.set_configuration("source", value, id, true)
end

function node.start(id)
  if node.is_reading(id) then
    if id then
      return false, "failed precondition \"is_reading(\"" .. id .. "\") == false\""
    else
      return false, "failed precondition \"is_reading() == false\""
    end
  end

  -- Connect.
  if not node.is_connected(id) then
    local result, message = node.connect(id)
    if not result then
      return result, message
    end
  end

  if id then
    if not manager:start(id) then
      return false, "failed to start reading from " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    if not manager:start() then
      return false, "failed to start reading from at least one " .. _NAME .. " in configuration"
    end
  end

  return true, ""
end

function node.start_take(name, description)
  if node.is_taking() then
    return false, "failed precondition, \"is_taking() == false\""
  end

  -- Start reading.
  if not node.is_reading() then
    local result, message = node.start()
    if not result then
      return result, message
    end
  end

  -- Create default parameter values.
  if not name then
    name = ""
  end
  if not description then
    description = ""
  end 

  -- Start take.
  if not manager:start_take(name, description) then
    return false, "failed to start take"
  end

  return true, ""
end

function node.stop(id)
  if not node.is_reading(id) then
    if id then
      return false, "failed precondition \"is_reading(\"" .. id .. "\") == true\""
    else
      return false, "failed precondition \"is_reading() == true\""
    end
  end

  -- Stop take.
  if node.is_taking() then
    local result, message = node.stop_take()
    if not result then
      return result, message
    end
  end

  -- Stop reading.
  if id then
    if not manager:stop(id) then
      return false, "failed to stop reading from " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    if not manager:stop() then
      return false, "failed to stop reading from at least one " .. _NAME .. " in configuration"
    end
  end

  return true, ""
end

function node.stop_take()
  if not manager:is_taking() then
    return false, "failed precondition, \"is_taking() == true\""
  end

  -- Stop take.
  if not manager:stop_take() then
    return false, "failed to stop take"
  end

  return true, ""
end

function node.take()
  return manager:take()
end

function node.track_take(filename)
  if not filename then
    filename = ""
  end

  _history["track_take"] = filename

  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end

  if not manager:track_take(filename) then
    return false, "failed to track take from file \"" .. filename .. "\""
  end
  
  _history["track_take"] = node.system.file_canonical(filename) 
  
  return true, ""
end

function node.write_configuration(id, factory)
  if not node.is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  if node.is_connected(id) then
    return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
  end

  if nil == write_factory then
    write_factory = false
  end

  if base.type(manager["write_configuration"]) == base.type(function () end) then
    if not manager:write_configuration(id, write_factory) then
      return false, "failed to write configuration to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    return false, "not implemented for all devices"
  end

  return true, ""
end

function node.write_user_data(id, data)
  if not node.is_id(id) then
    if not id then
      id = ""
    end
    return false, "failed precondition \"is_id(\"" .. id .. "\") == true\""
  end
  
  if not data then
    data = {}
  end
  
  if #data <= 0 then
    return false, "failed precondition \"#data > 0\""
  end
  
  -- Accept table of up to 30 numbers.
  if base.type(data) == base.type({}) and #data > 30 then
    return false, "failed table precondition \"#data <= 30\""
  end

  -- Accept a string of up to 120 characters
  if base.type(data) == base.type("") and #data > 120 then
    return false, "failed string precondition \"#data <= 120\""
  end

  if base.type(manager["write_user_data"]) == base.type(function () end) then
    if not manager:write_user_data(id, data) then
      return false, "failed to write user data to " .. _NAME .. " id, \"" .. id .. "\""
    else
      return true, ""
    end
  else
    return false, "user data interface not implemented"
  end
end


function node.usb.restore_configuration(id)
  if not node.is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  if node.is_connected(id) then
    return false, "failed precondition \"is_connected(\"" .. id .. "\") == false\""
  end

  if base.type(manager["restore_configuration_usb"]) == base.type(function () end) then
    if not manager:restore_configuration_usb(id) then
      return false, "failed to restore factory configuration to " .. _NAME .. " id, \"" .. id .. "\""
    end
  else
    return false, "not implemented for USB devices"
  end

  return true, ""
end


function node.system.calibrate_from_take(id, calibrate_accelerometer, calibrate_gyroscope_only)
  if not node.have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not node.is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  if not node.system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end
  
  -- Only calibrate the accelerometers if we specifically ask for it.
  if nil == calibrate_accelerometer then
    calibrate_accelerometer = false
  end
  
  -- Gyroscope only mode. Do not rotate, stationary sensor data.
  if nil == calibrate_gyroscope_only then
    calibrate_gyroscope_only = false
  end

  if not manager:calibrate_from_take(id, calibrate_accelerometer, calibrate_gyroscope_only) then
    return false, "failed to generate " .. _NAME .. " calibration from take data"
  end
  
  return true, ""
end

function node.system.configuration_matches_take()
  if not node.have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not node.is_configured(id) then
    return false, "failed precondition \"is_configured(\"" .. id .. "\") == true\""
  end
  
  if not manager:configuration_matches_take() then
    return false, "current configuration does not match current take"
  end

  return true, ""
end

function node.system.console_client(address, port)
  if not address or string.len(address) == 0 then
    address = "127.0.0.1"
  end
  if not port then
    port = 0
  end
  
  if not manager:console_client(address, port) then
    return false, "failed to create connection to address \"" .. address .. "\" on port " .. port
  end
  
  return true, ""
end

function node.system.disable_input()
  if not manager:disable_input() then
    return false, "failed to disable remote input"
  end

  return true, ""
end

function node.system.enable_input(address, port)
  if not address then
    address = ""
  end
  if not port then
    port = 0
  end
  
  if not manager:enable_input(address, port) then
    return false, "failed to enable remote input address \"" .. address .. "\" on port " .. port
  end
  
  return true, ""
end

function node.system.export_type()
  -- Export type definitions.
  local bvh = {
    ["description"] = "Biovision BVH",
    ["option"] = "header=1,precision=0,prepend_rest=1"
  }
  local csv = {
    ["description"] = "Comma Separated Value (CSV) text format",
    ["option"] = "header=1,precision=0,space=0"
  }
  local dae = {
    ["description"] = "COLLADA Schema",
    ["option"] = "precision=0,xsi=0"
  }
  local c3d = {
    ["description"] = "C3D (Coordinate 3D) file format",
    ["option"] = "all=0,signed=0"
  }

  local valid_type = {
    ["bvh"] = bvh,
    ["csv"] = csv,
    ["dae"] = dae,
    ["c3d"] = c3d
  }
  
  if not node._BUS then
    valid_type["fbx"] = {
      ["description"] = "Autodesk FBX",
      ["option"] = "binary=1,format=-1,marker=1,hik_marker=0"
    }
  end

  return valid_type
end

function node.system.export_stream_type()
  local valid_type = {
    ["csv"] = {},
    ["c3d"] = {}
  }

  for key,value in base.pairs(node.system.export_type()) do
    if valid_type[key] then
      value["option"] = value["option"] .. ",output=1,timestamp=0"
      valid_type[key] = value
    end
  end

  return valid_type
end

function node.system.export_default_type()
  if not _history["export_type"] then
    local type = node.system.get_default("export_type")
    if not type then
      if not node._BUS then
        type = "fbx"
      else
        type = "csv"
      end
    end

    return type
  else
    return _history["export_type"]
  end
end

function node.system.file_exists(filename)
  if not filename then
    filename = ""
  end

  if not manager:file_exists(filename) then
    return false
  end

  return true
end

function node.system.file_canonical(filename)
  if not filename then
    filename = ""
  end

  return manager:file_canonical(filename)
end

function node.system.geocode_address(address, name)
  if not address then
    address = ""
  end

  if not name then
    name = ""
  end

  if not manager:geocode_address(address, name) then
    return false, "failed to geocode address \"" .. address .. "\""
  end

  return true, ""
end

function node.system.get_default(name)
  if not name then
    name = ""
  end
  
  return manager:get_default(name)
end

function node.system.get_history()
  return _history
end

function node.system.get_local_mode()
  local mode = node.system.get_default("local_mode")

  if mode then
    mode = mode + 0
  end

  for key,value in base.pairs(node.system.local_mode()) do
    if key == mode then
      return value
    end
  end

  return nil
end

function node.system.get_location_list()
  if base.type(manager["get_location_list"]) == base.type(function () end) then
    return manager:get_location_list()
  else
    return nil
  end
end

function node.system.get_preference()
  return manager:get_preference()
end

function node.system.get_ractor_list()
  if base.type(manager["get_ractor_list"]) == base.type(function () end) then
    return manager:get_ractor_list()
  else
    return nil
  end
end

function node.system.get_service()
  return _service
end

function node.system.get_settings(id)
  if not id then
    id = ""
  end

  return manager:get_settings(id)
end

function node.system.get_system_info()
  if base.type(manager["get_system_info"]) == base.type(function () end) then
    return manager:get_system_info()
  else
    return nil
  end
end

function node.system.set_battery_state(level, state)
  if base.type(manager["set_battery_state"]) == base.type(function () end) then
    return manager:set_battery_state(level, state)
  else
    return nil
  end
end

function node.system.get_wifi_list()
  if base.type(manager["get_wifi_list"]) == base.type(function () end) then
    return manager:get_wifi_list()
  else
    return nil
  end
end

function node.system.get_zeroconf_list()
  if base.type(manager["get_zeroconf_list"]) == base.type(function () end) then
    return manager:get_zeroconf_list()
  else
    return nil
  end
end

function node.system.initialize()
  if false == _initialized then
    local filename = node._initialize_filename
  
    if not node.system.file_exists(filename) then
      return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
    end

    if node.load_script(filename) then
      _initialized = true
    else
      return false, "failed to load initialization file, \"" .. filename .. "\""
    end
  end

  return true, ""
end

function node.system.initialize_session()
  if not manager:initialize_session() then
    return false, "failed to initialize session settings"
  end

  _history = {}

  return true, ""
end

function node.system.is_filename(filename)
  if not filename then
    filename = ""
  end

  return manager:is_filename(filename)
end

function node.system.is_initialized()
  return true == _initialized
end

function node.system.load_plugin(name)
  if node.is_connected() then
    return false, "failed precondition, \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if not name then
    name = ""
  end

  if base.type(manager["load_plugin"]) == base.type(function () end) then
    if not manager:load_plugin(name) then
      if string.len(name) > 0 then
        return false, "failed load plugin named \"" .. name .. "\""
      else
        return false, "failed to load at least one plugin"
      end
    end
  else
    return false, "plugin interface not implemented"
  end

  return true, ""
end

function node.system.local_mode()
  local result = {
    [0] = "NONE",
    [1] = "WORLD",
    [2] = "SENSOR",
    [3] = "WORLD_HEADING",
    [4] = "HIERARCHY",
    [5] = "MARKER"
  }
  return result
end

function node.system.location(latitude, longitude, elevation, address)
  if latitude <= -90 or latitude >= 90 then
    return false, "failed precondition \"-90 < latitude < 90\""
  end
  
  if longitude <= -180 or longitude >= 180 then
    return false, "failed precondition \"-180 < longitude < 180\""
  end
  
  if elevation < -1000 or elevation > 600000 then
    return false, "failed precondition \"-1000 <= elevation <= 600000\""
  end
  
  if not address then
    address = ""
  end

  if not manager:location(latitude, longitude, elevation, address) then
    return false, "failed to set location, invalid parameter"
  end
  
  return true, ""
end

function node.system.log(filename)
  if not filename then
    filename = ""
  end

  if not node.system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end
  
  if node.system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end  

  if not manager:log(filename) then
    return false, "failed to set log file \"" .. filename .. "\""
  end
  
  return true, ""
end

function node.system.magnetic_from_take(id)
  if not node.have_take() then
    return false, "failed precondition \"have_take() == true\""
  end
  if not node.is_connected(id) then
    return false, "failed precondition \"is_connected(\"" .. id .. "\") == true\""
  end
  if not node.system.configuration_matches_take() then
    return false, "failed precondition \"system.configuration_matches_take() == true\""
  end

  if not manager:magnetic_from_take(id) then
    return false, "failed to generate " .. _NAME .. " magnetic calibration from take data"
  end
  
  return true, ""
end

function node.system.open_database(filename)
  if not filename then
    filename = ""
  end

  if not node.system.file_exists(filename) then
    return false, "failed precondition \"system.file_exists(\"" .. filename .. "\") == true\""
  end
  
  if node.system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end

  if not manager:open_database(filename) then
    return false, "failed to open database file \"" .. filename .. "\""
  end

  -- Load up export type preference.
  local type = node.system.get_default("export_type")
  if type then
    local valid_type = node.system.export_type()
    if valid_type[type] then
      _history["export"] = "take." .. type
      _history["export_type"] = type
    end
  end

  return true, ""
end

function node.system.print(...)
  local arg = table.pack(...)

  local result = ""
  for key,value in base.ipairs(arg) do
    result = result .. base.tostring(value)
  end
  result = result .. "\n"

  manager:print(result)
end

function node.system.quit()
  return manager:quit()
end

function node.system.ractor(name, height, arm, leg)
  if not name then
	name = ""
  end

  if not height then
    height = -1
  end

  if not arm then
    arm = -1
  end

  if not leg then
    leg = -1
  end

  if not manager:ractor(name, height, arm, leg) then
    return false, "failed to configure ractor from measurements, invalid parameter"
  end

  return true, ""
end

function node.system.republish_services()
  return manager:republish_services()
end

function node.system.reset_wifi()
  return manager:reset_wifi()
end

function node.system.restart()
  return manager:restart()
end

function node.system.save_initialization()
  local filename = node._initialize_filename
  local script_filename = "/index.lua"
  
  if not node.system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end 
  if not node.system.file_exists(script_filename) then
    return false, "failed precondition \"system.file_exists(\"" .. script_filename .. "\") == true\""
  end

  if not manager:save_initialization(filename, script_filename) then
    return false, "failed to save initialization to file, \"" .. filename .. "\""
  end

  -- If the default location file exists at this point, write the
  -- current configuration out to it.
  if node.system.file_exists(node._location_filename) then
    local result, message = node.system.save_location()
    if not result then
      return false, message
    end
  end

  return node.system.initialize()
end

function node.system.save_location(filename)
  local script_filename = "/location.lua"

  if not filename then
    filename = node._location_filename
  end
  
  if not node.system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end 
  if not node.system.file_exists(script_filename) then
    return false, "failed precondition \"system.file_exists(\"" .. script_filename .. "\") == true\""
  end
  
  if not manager:save_location(filename, script_filename) then
    return false, "failed to save current location to file, \"" .. filename .. "\""
  end

  return true, ""
end

function node.system.save_ractor(filename)
  local script_filename = "/ractor.lua"

  if not filename then
    filename = node._ractor_filename
  end
  
  if not node.system.is_filename(filename) then
    return false, "failed precondition \"system.is_filename(\"" .. filename .. "\") == true\""
  end 
  if not node.system.file_exists(script_filename) then
    return false, "failed precondition \"system.file_exists(\"" .. script_filename .. "\") == true\""
  end
  
  if not manager:save_ractor(filename, script_filename) then
    return false, "failed to save current ractor definition to file, \"" .. filename .. "\""
  end

  return true, ""
end

function node.system.service_exists(name)
  if base.type(manager[name]) == base.type(function() end) then
    return true
  else
    return false
  end
end

function node.system.set_date_time(timestamp)
  if not timestamp then
    timestamp = ""
  end
  
  return manager:set_date_time(timestamp)
end

function node.system.set_data_path(path)
  if not path then
    path = ""
  end
  if node.system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end  
  
  if not manager:set_data_path(path) then
    return false, "failed to set data path \"" .. path .. "\""
  end
  
  return true, ""
end

function node.system.set_default(name, value)
  if not name then
    name = ""
  end
  if not value then
    value = ""
  end 
  
  return manager:set_default(name, value)
end

function node.system.set_local_mode(value)
  if not value then
    value = 1
  end
  
  if base.type(value) == base.type("") then
    value = string.upper(value)

    for i,name in base.pairs(node.system.local_mode()) do
      if name == value then
        value = i
        break
      end
    end

  elseif value < 0 then
    value = 0
  elseif value > 5 then
    value = 5
  end
  
  return manager:set_local_mode(value)
end

function node.system.set_search_path(path)
  if not path then
    path = ""
  end
  if node.system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end 
   
  if not manager:set_search_path(path) then
    return false, "failed to set search path \"" .. path .. "\""
  end
  
  return true, ""
end

function node.system.set_wifi(hwid, essid, password)
  if not hwid then
    hwid = ""
  end
  if not essid then
    essid = ""
  end 
  if not password then
    password = ""
  end

  if manager:set_wifi(hwid, essid, password) then
    return true, ""
  else
    return false, "failed to select wifi network"
  end
end

function node.system.shutdown(id)
  if not(id) then
    id = ""
  end
  
  if manager:shutdown(id) then
    return true, ""
  else
    if node.is_id(id) then
      return false, "failed to send shutdown command to " .. _NAME .. " id, \"" .. id .. "\""
    else
      return false, "failed to send shutdown command"
    end
  end
end

function node.system.sleep(seconds)
  if not(seconds) then
    seconds = 0
  end

  return manager:sleep(seconds)
end

function node.system.start_services(service)
  if node.system.is_initialized() then
    return false, "failed precondition \"system.is_initialized() == false\""
  end

  local result = true
  local message = ""

  for name,port in base.pairs(service) do
    if base.type(manager[name]) == base.type(function() end) then
      -- Lua syntax to call a member function by string name,
      -- instance:method(arg) == instance["method"](instance, arg)
      service[name] = manager[name](manager, port)

      if not service[name] then
        -- Only describe the first failed service.
        if result then
          message = "failed to start service \"" .. name .. "\" on port " .. base.tostring(port)
        end
        result = false
      else
        _service[name] = service[name]
      end
    else
      -- Only describe the first failed service.
      if result then
        message = "service \"" .. name .. "\" not implemented, failed to start on port " .. base.tostring(port)
      end
      result = false
    end
  end

  return result, message
end

function node.system.test_wifi(hwid, essid, password)
  if not hwid then
    hwid = ""
  end
  if not essid then
    essid = ""
  end 
  if not password then
    password = ""
  end

  if manager:test_wifi(hwid, essid, password) then
    return true, ""
  else
    return false, "failed to select wifi network"
  end
end

function node.system.unique_id(id)
  if not node.is_id(id) then
    return false, "failed precondition \"is_id(\"" .. id .. "\") == true\""
  end
  
  if not node.is_configured(id) then
    return true, id
  end

  local postfix = 1

  -- Search for an existing integer postfix. If there is
  -- one, use that as our base.
  local i, j = string.find(id, "%d+$")
  if i and j then
    postfix = base.tonumber(string.sub(id, i, j)) + 1
    id = string.sub(id, 1, i-1)
  end

  return node.system.unique_id(id .. base.tostring(postfix))
end

function node.system.unload_plugin(name)
  if node.is_connected() then
    return false, "failed precondition, \"is_connected() == false\""
  end
  if node.connected() then
    return false, "failed precondition \"connected() == nil\""
  end
  
  if not name then
    name = ""
  end  

  if base.type(manager["unload_plugin"]) == base.type(function () end) then
    if not manager:unload_plugin(name) then
      return false, "failed to unload at least one plugin"
    end
  else
    return false, "plugin interface not implemented"
  end

  return true, ""
end

function node.system.command_to_string(format, command, ...)
  local arg = table.pack(...)

  local fn = node[command]

  -- Split commands of the form "table.command" and
  -- bind fn to the node[table][command] entry.
  local command1, command2
  _, _, command1, command2 = string.find(command, "^([^%.]+)%.([^%.]+)$")
  if command1 and command2 then
    fn = node[command1][command2]
  end
  
  if not fn then
    base.error("function not found in node interface, \"node." .. command .. "\"")
  end

  -- Manually dispatch a method call with up to 4 arguments.
  local result = ""
  local n = #arg
  if n > 0 then
    if n > 1 then
      if n > 2 then
        if n > 3 then
          result = format(fn(arg[1], arg[2], arg[3], arg[4]))
        else
          result = format(fn(arg[1], arg[2], arg[3]))
        end
      else
        result = format(fn(arg[1], arg[2]))
      end
    else
      result = format(fn(arg[1]))
    end
  else
    result = format(fn())
  end

  return result
end


function node.xml.command_to_xml(command, ...)
  local arg = table.pack(...)

  return
    "<?xml version=\"1.0\"?>" ..
    "<methodResponse><params>" ..
    node.system.command_to_string(node.xml.result_to_xml, command, table.unpack(arg)) ..
    "</params></methodResponse>"
end

function node.xml.command_table_to_xml(command, ...)
  local module_command

  local command1, command2
  _, _, command1, command2 = string.find(command, "^([^%.]+)%.([^%.]+)$")
  if command1 and command2 then
    module_command = node[command1][command2]
  end

  return node.xml.command_to_xml(module_command, ...)
end

function node.xml.encode_attribute(value)
  local result = node.xml.encode_string(value) 
  result = string.gsub(result, "\"", "&quot;")
  return result
end

function node.xml.encode_string(value)
  local result = base.tostring(value) 
  result = string.gsub(result, "&", "&amp;")
  result = string.gsub(result, "<", "&lt;")
  result = string.gsub(result, ">", "&gt;")
  result = string.gsub(result, "\\", "\\\\")
  return result
end

function node.xml.result_to_xml(...)
  local arg = table.pack(...)

  -- Make a table of type conversions for
  -- XML output.
  local xml_type = {
    ["string"]  = base.type(""),
    ["number"]  = base.type(0.0),
    ["boolean"] = base.type(true)
  }

  local result = ""
  for key,value in base.ipairs(arg) do
    local value_type = xml_type[base.type(value)]
    if not value_type then
      value = base.tostring(value)
      value_type = base.type(value)
    end
    
    result = result .. "<param><value><" .. value_type
    if nil ~= value then
      if base.type(true) == base.type(value) then
        if true == value then
          value = 1
        else
          value = 0
        end
      end

      result =
        result .. ">" .. node.xml.encode_string(value) ..
        "</" .. value_type .. ">"
      else
        result = result .. "/>"
    end
    result = result .. "</value></param>"
  end

  return result
end

function node.xml.history_to_xml()
  local result = ""

  local history = node.system.get_history()
  if history then
    result = result .. "<history"
    local key, value
    for key,value in base.pairs(history) do
      result = result .. " " .. key .. "=\"" .. node.xml.encode_attribute(value) .. "\""
    end
    result = result .. "/>"
  end
  
  return result
end

function node.xml.take_to_xml()
  local result = ""

  local value = node.take()
  if value then
    result = result ..
      "<take" ..
      " name=\"" .. node.xml.encode_attribute(value.name) .. "\"" ..
      " description=\"" .. node.xml.encode_attribute(value.description) .. "\"" ..
      " loaded_from=\"" .. node.xml.encode_attribute(value.loaded_from) .. "\"" ..
      ">"
    result = result .. "</take>"
  end
  
  return result
end

function node.json.encode_string(value)
  local result = base.tostring(value) 
  result = string.gsub(result, "\\", "\\\\")
  result = string.gsub(result, '"', '\\"')
  result = string.gsub(result, '\t', '\\t')
  result = string.gsub(result, '\n', '\\n')
  return result
end

function node.json.is_list(value)
  -- By our convention, a list is any table with ascending integer keys
  -- starting at 1.
  if base.type({}) ~= base.type(value) then
    return false
  end

  if 0 == #value then
    return false
  end

  local index = 1
  for k,v in base.pairs(value) do
    if base.type(0) ~= base.type(k) then
      return false
    end

    if k ~= index then
      return false
    end

    index = index + 1
  end

  return true
end

function node.json.encode(value, list)
  if nil == value then
    return 'null';
  end
  
  local value_type = base.type(value)
  
  -- Regular strings.
  if base.type("") == value_type then
    return '"' .. node.json.encode_string(value) .. '"'
  end

  -- Numbers and booleans.
  if base.type(0) == value_type or base.type(true) == value_type then
    return base.tostring(value)
  end
  
  -- Tables.
  if base.type({}) == value_type then
    if nil == list then
      list = node.json.is_list(value)
    end

    local kv = {}
    for k,v in base.pairs(value) do
      if list then
        table.insert(kv, node.json.encode(v))
      else
        table.insert(kv, '"' .. node.json.encode_string(k) .. '":' .. node.json.encode(v, ('node' == k) or nil))
      end
    end
    
    if list then
      return "[" .. table.concat(kv, ",") .. "]"
    else
      return "{" .. table.concat(kv, ",") .. "}"
    end
  end
  
  -- Unknown. Null string.
  return "null"
end

function node.json.command_to_json(command, ...)
  return
    "{\"result\": " ..
    node.system.command_to_string(node.json.result_to_json, command, ...) ..
    ", \"code\": 0}"
end

function node.json.command_to_jsonrpc(command, ...)
  return
    node.system.command_to_string(node.json.result_to_json, command, ...)
end

function node.json.result_to_json(...)
  local arg = table.pack(...)

  local result = {}
  for key,value in base.ipairs(arg) do
    result[key] = value
  end

  return node.json.encode(result, true)
end


--
-- End public function definitions.
--

--
-- Return module style table of all public node.* definitions.
--
return node
