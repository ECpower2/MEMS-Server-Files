#
# @file    maya/scripts/shadow/contact.py
# @version 2.2
# @brief   Library of functions to set key frames on the weight channels of a
#          Shadow skeleton. Add, remove, and move contact points.
#
# (C) Copyright Motion Workshop 2015. All rights reserved.
#
# The coded instructions, statements, computer programs, and/or related
# material (collectively the "Data") in these files contain unpublished
# information proprietary to Motion Workshop, which is protected by
# US federal copyright law and by international treaties.
#
# The Data may not be disclosed or distributed to third parties, in whole
# or in part, without the prior written consent of Motion Workshop.
#
# The Data is provided "as is" without express or implied warranty, and
# with no claim as to its suitability for any purpose.
#

from .mDisplayString import mDisplayString

import maya.cmds as cmds
import math


class point:
    """
    Contact point between the Shadow skeleton and the environment. Could be a
    foot step, sitting on something, a hand plant, etc. Any joint can be a
    contact point.

    A contact point is activated using its "weight" channel. This class provides
    methods to manipulate the weight channels automatically based on a selected
    joint and a time window.
    """
    
    # Pick a curve with dense keyframes. Hips.rotateX is a good bet.
    DriverAttr = "rotateX"

    # The custom named attribute that contains our contact point weights.
    WeightAttr = "weight"

    def __init__(self):
        self.hips_list = []

    def add(self, replace=True, time_range=None):
        """
        Add a contact point on a joint (transform) node over a specified time
        range. Works on the active selection list.

        replace    set to True to remove all other contact points in the time
                   range.
        time_range a two element tuple or array that defines the start and end
                   time of the contact point. For example, (0.0, 10.0).
        """
        self.hips_list = []

        if time_range:
            rng = [time_range[0], time_range[1]]
        else:
            # Selected range in time
            rng = self.selected_time_range()
            if not rng:
                cmds.warning(mDisplayString("kErrorTimeRange"))
                return False

        # Selected transform node.
        list = cmds.ls(selection=True, type="transform", long=True)
        if not len(list):
            cmds.warning(mDisplayString("kErrorSelectNode"))
            return False

        for item in list:
            hips = self.find_root(item)
            if not hips:
                return False
            
            # Find our animation curve that defines the time channel.
            driver = self.find_animation(".".join([hips, self.DriverAttr]))
            # Find the actual key times that span our requested range.
            keytime = self.find_time(driver, rng)

            if not driver or not keytime:
                return False

            keyvalue = [0.0, 1.0, 1.0, 0.0]
            plug = ".".join([item, self.WeightAttr])
            if self.set_keys(plug, keytime, keyvalue):
                print(cmds.format(
                    mDisplayString("kInfoAddContact"),
                    stringArg=(str(keytime[1]), str(keytime[2]), str(item))))
            else:
                return False

            if replace:
                weight_list = self.find_weight_plugs(item, hips)
                if weight_list:
                    keyvalue = [1.0, 0.0, 0.0, 1.0]
                    for plug in weight_list:
                        self.set_keys(plug, keytime, keyvalue)

            # List of joint hierarchy root nodes that we operated on.
            self.hips_list.append(hips)

        return True

    def set_keys(self, plug, keytime, keyvalue):
        """
        Set key frames on a weight curve for an effector. Pass the plug since
        there may not be an animation curve yet.

        plug     contains the named plug we are operating on.
                 For example, "LeftToe.weight".
        keytime  contains the time value in an array.
                 For example, [10.0, 11.0, 25.0, 26.0].
        keyvalue contains the desired key frame values in an array.
                 For example, [0.0, 1.0, 1.0, 0.0].

        Change any existing keyframes between keytime[0] and keytime[-1] to
        equal keyvalue[1] which is the active value. Set lead in and lead out
        key frames to either keyvalue[0:-1] or to the existing curve values at
        those times.
        """
        curve = self.find_animation(plug)
        if curve:
            # Evaluate the animation curve at the beginning and end of the time
            # window.
            for k in [0, len(keytime) - 1]:
                key = keytime[k]

                value = cmds.keyframe(
                    plug, query=True, time=(key, key), eval=True)
                if value and len(value) > 0:
                    keyvalue[k] = value[0]

            # Remove any existing keys inside the time window. We want to start
            # with a clean slate. Otherwise, we would have to iterate through
            # all of them and set them to our target value.
            if len(keytime) >= 4:
                num_keyed = cmds.cutKey(plug,
                                        time=(keytime[1], keytime[-2]),
                                        clear=True)
        else:
            cmds.warning(cmds.format(
                mDisplayString("kErrorAnimCurve"),
                stringArg=str(plug)))

        # If all keys are the same value then we do not have to do anything.
        # This covers a curve that may ony have a t=0 and t=N key with 0 values.
        # There is no need to generate in betweens.
        keys_same = True
        for v in keyvalue:
            if not self.is_equivalent(keyvalue[0], v):
                keys_same = False
                break

        if keys_same:
            # No need to create any key frames. The curve already matches our
            # target values at all times.
            cmds.setAttr(plug, keyvalue[1])
            return True

        for k, v in enumerate(keytime):
            # Query existing key frame at time t.
            key_list = cmds.keyframe(plug, query=True, time=(v, v))

            num_keyed = 0
            if key_list and (1 == len(key_list)):
                num_keyed = cmds.keyframe(
                    plug,
                    time=(v, v),
                    valueChange=keyvalue[k],
                    absolute=True)
            else:
                num_keyed = cmds.setKeyframe(
                    plug,
                    inTangentType="linear",
                    outTangentType="step",
                    time=v,
                    value=keyvalue[k])

            if num_keyed <= 0:
                cmds.warning(cmds.format(
                    mDisplayString("kErrorKeyFrame"),
                    stringArg=(str(v), str(plug), str(keyvalue[k]))))
                return False

        # Setting the key frame on the curve does not update the attribute plug.
        # Manually set the attribute to update the scene graph.
        curve = self.find_animation(plug)
        if curve:
            value = cmds.getAttr(".".join([str(curve), "output"]))
            cmds.setAttr(plug, value)

        return True

    def find_animation(self, plug):
        """
        Return an animation curve that is connected to the named plug.

        For example:
            find_animation("Hips.rx") -> "Hips_rotateX_animCurveTA"
        """
        if not cmds.objExists(plug):
            return None

        list = cmds.keyframe(plug, query=True, name=True, hierarchy=True)
        if list and len(list):
            return list[0]

        return None

    def find_root(self, node):
        """
        Find the root joint of a skeleton.

        For example:
          find_root("LeftToe") -> "Hips"
        """
        while node:
            list = cmds.listRelatives(node, parent=True, type="joint", fullPath=True)
            if list:
                node = list[0]
            else:
                break

        return node

    def find_time(self, driver, rng):
        """
        Return a four element array of time values. The driver is an animation
        curve, hopefully with really dense keyframes. We will find four keys
        in the driver curve that span the begin and end of the requested time
        range.

        For example:
            find_time([10, 20]) -> [9.9, 10, 20, 20.1]
        """
        num_keys = cmds.keyframe(driver, query=True, keyframeCount=True)

        list = []
        for i in range(0, num_keys):
            time = cmds.keyframe(driver, query=True, index=(i, i))
            if not time:
                continue

            time = time[0]
            if 0 == len(list):
                list.append(time)
                if time >= rng[0]:
                    list.append(time)
                    list.append(time)
            elif 1 == len(list):
                if time >= rng[0]:
                    list.append(time)
                    list.append(time)
                else:
                    list[0] = time
            elif 2 == len(list):
                list.append(time)
            elif 3 == len(list):
                if (time > rng[1]) or (num_keys - 1 == i):
                    list.append(time)
                    break
                else:
                    list[2] = time

        if 4 != len(list):
            return None

        return list

    def find_weight_plugs(self, node, hips):
        """
        Give a joint node in a hierarchy, and the root node of the same
        hierarchy, find all other joints that have an animated weight plug.

        For example:
          find_weight_plugs("LeftToe", "Hips") ->
            ["Hips.weight", "LeftHeel.weight", "RightHeel.weight", ...]
        """
        weight_list = []

        list = cmds.listRelatives(hips, allDescendents=True, type="joint", fullPath=True)
        list.append(hips)

        for item in list:
            if node == item:
                continue

            plug = ".".join([item, self.WeightAttr])
            curve = self.find_animation(plug)
            if curve:
                weight_list.append(plug)

        if not len(weight_list):
            return None

        return weight_list

    def is_equivalent(self, a, b):
        """
        Return true iff floating point values a and b are equivalent. Fuzzy
        comparison operator.
        """
        if math.fabs(a - b) > 0.001:
            return False
        else:
            return True

    def selected_time_range(self):
        # Maya global timeControl node.
        tc = "timeControl1"
        if not cmds.timeControl(tc, query=True, globalTime=True):
            # Missing required time control node, give up.
            return False

        rng = []
        if cmds.timeControl(tc, query=True, rangeVisible=True):
            rng = cmds.timeControl(tc, query=True, rangeArray=True)

        if 2 != len(rng):
            return None

        return rng

    def simplify_weight(self, plug):
        curve = self.find_animation(plug)
        if not curve:
            return False

        num_keys = cmds.keyframe(curve, query=True, keyframeCount=True)
        for i in range(0, num_keys):
            value = cmds.keyframe(curve, query=True, eval=True, index=(i, i))
            if not value:
                continue

            value = value[0]
            if value > 0.01:
                value = 1.0
            else:
                value = 0.0

            cmds.keyframe(curve, valueChange=value, absolute=True, index=(i, i))
#
# END class point
#
