#
# @file    maya/scripts/shadow/device.py
# @version 2.2
# @brief   Library of Python functions that implements a basic Maya user
#          interface for the mDevice mocap device. Interacts with Maya
#          and also sends some commands to the device server.
#
# (C) Copyright Motion Workshop 2015. All rights reserved.
#
# The coded instructions, statements, computer programs, and/or related
# material (collectively the "Data") in these files contain unpublished
# information proprietary to Motion Workshop, which is protected by
# US federal copyright law and by international treaties.
#
# The Data may not be disclosed or distributed to third parties, in whole
# or in part, without the prior written consent of Motion Workshop.
#
# The Data is provided "as is" without express or implied warranty, and
# with no claim as to its suitability for any purpose.
#

from . import MotionSDK as SDK
from .mDisplayString import mDisplayString

import urllib2
from functools import partial

try:
    import maya.cmds as cmds
    import maya.mel as mel

    in_maya = True
except ImportError:
    in_maya = False


class ui:
    """
    Maya UI control panel for the Shadow device. Show a smalled tabbed
    interface with some buttons to run common tasks. Provide real-time preview,
    take import, and commands for contact point editing.

    Route all commands through the device.action class.
    """
    def __init__(self):
        # Window instance name. Use a fixed name so that we only have one open
        # window of this type at a time.
        self.name = "shadow_device_ui"

        # Title displayed in the window bar.
        self.title = mDisplayString("kShadow")

        self.status_attr = "shadow_device_time.status"
        self.script_job = 0
        if cmds.objExists(self.status_attr):
            self.script_job = cmds.scriptJob(
                attributeChange=[self.status_attr, self.change_status])

        if in_maya:
            self.create_window()

    def __del__(self):
        if self.script_job > 0 and cmds.scriptJob(exists=self.script_job):
            cmds.scriptJob(kill=self.script_job)

    def change_status(self):
        value = cmds.getAttr(self.status_attr)
        if value > 0:
            print(mDisplayString("kHUDRecording"))
        else:
            print(mDisplayString("kHUDPreview"))

    def create_window(self):
        # If our name already exists, delete the instance.
        if cmds.window(self.name, exists=True) != 0:
            cmds.deleteUI(self.name)

        self.action = action()

        self.window = cmds.window(
            self.name,
            title=self.title,
            width=300, height=200,
            menuBar=True)

        cmds.setParent('..')

        self.tabs = cmds.tabLayout(
            innerMarginWidth=5,
            innerMarginHeight=5)

        self.preview = self.preview_layout()
        self.take = self.take_layout()
        self.pref = None

        show_edit = mel.eval(
            "global int $MDEVICE_SHOW_EDIT;"
            " $mdevice_show_edit=$MDEVICE_SHOW_EDIT;")
        if (1 == show_edit) and self.action.have_plugin():
            self.edit = self.edit_layout()
        else:
            self.edit = None

        tabLabel = [
            (self.preview, mDisplayString("kPreview")),
            (self.take, mDisplayString("kImport"))
        ]

        if self.edit:
            tabLabel.append((self.edit, mDisplayString("kEdit")))

        if self.pref:
            tabLabel.append((self.pref, mDisplayString("kPreference")))

        # Read the index of the last selected tab. User preference.
        tab_index = 1
        tab_var = self.name + ".tab"
        if (cmds.optionVar(exists=tab_var)):
            tab_index = int(cmds.optionVar(query=tab_var))
            if tab_index > len(tabLabel):
                tab_index = len(tabLabel)

        cmds.tabLayout(
            self.tabs,
            edit=True,
            tabLabel=tabLabel,
            selectTabIndex=tab_index,
            changeCommand=self.change_tab)

        cmds.showWindow(self.window)

    def change_tab(self):
        value = cmds.tabLayout(
            self.tabs,
            query=True,
            selectTabIndex=True)

        cmds.optionVar(
            stringValue=(self.name + ".tab", value))

    def pref_layout(self):
        layout = cmds.rowColumnLayout(
            columnSpacing=[(1, 10)],
            rowSpacing=(1, 10),
            numberOfColumns=1)

        self.address = cmds.textFieldGrp(
            label=mDisplayString("kAddress"),
            adjustableColumn=2,
            columnAttach=[(1, "right", 5), (2, "both", 0)],
            columnWidth=[(1, 100), (2, 100)],
            text=self.action.host,
            changeCommand=self.action.change_address)

        cmds.setParent("..")

        return layout

    def preview_layout(self):
        layout = cmds.rowColumnLayout(
            columnSpacing=[(1, 10), (2, 10)],
            rowSpacing=[(1, 0)],
            numberOfColumns=2)

        self.load_skeleton = cmds.button(
            label=mDisplayString("kLoadSkeleton"),
            annotation=mDisplayString("kLoadSkeletonAnnot"),
            command=self.action.create_skeleton)
        self.load_marker = cmds.checkBox(
            label=mDisplayString("kMarkers"),
            annotation=mDisplayString("kMarkersAnnot"),
            value=self.action.marker,
            changeCommand=partial(self.action.change_integer, "marker"))

        # Can't figure out how to include a row margin. Hack in separator
        # controls for now. Probably make a better layout once all of the
        # features are stable.
        cmds.separator(visible=False, height=10)
        cmds.separator(visible=False, height=10)

        self.start_device = cmds.button(
            label=mDisplayString("kStartPreview"),
            annotation=mDisplayString("kStartPreviewAnnot"),
            command=self.action.start_device)
        self.stop_device = cmds.button(
            label=mDisplayString("kStopPreview"),
            annotation=mDisplayString("kStopPreviewAnnot"),
            command=self.action.stop_device)

        cmds.separator(visible=False, height=10)
        cmds.separator(visible=False, height=10)

        self.set_pose = cmds.button(
            label=mDisplayString("kSetPose"),
            annotation=mDisplayString("kSetPoseAnnot"),
            command=self.action.set_pose)
        self.set_pose_marker = cmds.checkBox(
            label=mDisplayString("kRestPose"),
            annotation=mDisplayString("kRestPoseAnnot"),
            value=self.action.pose_marker,
            changeCommand=partial(self.action.change_integer, "pose_marker"))

        cmds.separator(visible=False, height=10)
        cmds.separator(visible=False, height=10)

        self.start_record = cmds.button(
            label=mDisplayString("kStartTake"),
            annotation=mDisplayString("kStartTakeAnnot"),
            command=self.action.start_record)
        self.stop_record = cmds.button(
            label=mDisplayString("kStopTake"),
            annotation=mDisplayString("kStopTakeAnnot"),
            command=self.action.stop_record)

        cmds.setParent("..")

        return layout

    def take_layout(self):
        layout = cmds.rowColumnLayout(
            columnSpacing=[(1, 10)],
            rowSpacing=(1, 0),
            numberOfColumns=1)

        self.import_take = cmds.button(
            label=mDisplayString("kImportTake"),
            annotation=mDisplayString("kImportTakeAnnot"),
            command=self.action.import_take)

        cmds.separator(visible=False, height=10)

        enable = self.action.have_plugin()

        self.import_character = cmds.checkBox(
            label=mDisplayString("kUseCharacter"),
            annotation=mDisplayString("kUseCharacterAnnot"),
            value=self.action.character,
            enable=enable,
            changeCommand=partial(self.action.change_integer, "character"))

        self.import_fbx = cmds.checkBox(
            label=mDisplayString("kUseFBX"),
            annotation=mDisplayString("kUseFBXAnnot"),
            value=self.action.fbx,
            enable=enable,
            changeCommand=partial(self.action.change_integer, "fbx"))

        # Leave main layout.
        cmds.setParent("..")

        return layout

    def edit_layout(self):
        layout = cmds.rowColumnLayout(
            columnSpacing=[(1, 10), (2, 10)],
            rowSpacing=(1, 0),
            numberOfColumns=2)

        self.create_rig = cmds.button(
            label=mDisplayString("kAddContact"),
            annotation=mDisplayString("kAddContactAnnot"),
            command=self.action.add_contact)

        self.import_character = cmds.checkBox(
            label=mDisplayString("kReplaceExisting"),
            annotation=mDisplayString("kReplaceExistingAnnot"),
            value=self.action.contact,
            enable=False,
            changeCommand=partial(self.action.change_integer, "contact"))

        # Leave main layout.
        cmds.setParent("..")

        return layout

#
# END class ui
#


class action:
    """
    Utility class implements actions performed by the shadow.device.ui class.
    Just keep the buttons and layout separate from the commands.
    """
    def __init__(self):
        self.name = "shadow_device_action"

        # Host address we are working with.
        self.host = "127.0.0.1"
        self.port = 32075

        self.character = 1
        self.marker = 1
        self.mass = 0
        self.fbx = 0
        self.contact = 1
        self.pose_marker = 0

        # Read preferences.
        host_var = self.name + ".host"
        if (cmds.optionVar(exists=host_var)):
            self.host = str(cmds.optionVar(query=host_var))

        self.__load_integer("character")
        self.__load_integer("marker")
        self.__load_integer("mass")
        self.__load_integer("fbx")
        self.__load_integer("contact")
        self.__load_integer("pose_marker")

        # Make the console connection part of the window class so
        # we can reuse it. Connect at the first remote request.
        self.client = None

        # Read the version string from the mDevice library. Also ensures
        # that our library is loaded and ready for use.
        mel.eval("mDevice();")
        self.plugin = mel.eval("mDevice_load_plugin();")

        if not self.have_plugin():
            self.character = 0
            self.fbx = 1

    def __client(self):
        """
        Internal use. Return a LuaConsole scripting node to send remote
        commands to the server.
        """
        if None == self.client:
            try:
                self.client = SDK.Client(self.host, self.port)

                print(cmds.format(
                    mDisplayString("kInfoConnect"),
                    stringArg=self.host))
            except:
                self.client = None
                cmds.error(cmds.format(
                    mDisplayString("kErrorConnect"),
                    stringArg=self.host))

        return self.client

    def __lua_node(self):
        """
        Internal use. Return a LuaConsole scripting node to send remote
        commands to the server.
        """
        return SDK.LuaConsole.Node(self.__client())

    def __load_integer(self, name):
        """
        Internal use. Load a integer preference field.
        """
        name_var = self.name + "." + name
        if (cmds.optionVar(exists=name_var)):
            setattr(self, name, int(cmds.optionVar(query=name_var)))

    def change_integer(self, name, value):
        """
        Callback. The user changed an integer field.
        """
        value = int(value)
        setattr(self, name, value)

        cmds.optionVar(
            intValue=(self.name + "." + name, value))

    def change_address(self, data):
        """
        Callback. The user changed the address text field.
        """
        self.host = data
        if 0 == len(self.host):
            self.host = "127.0.0.1"

        # Write host name as a user preference.
        cmds.optionVar(
            stringValue=(self.name + ".host", self.host))

        if None != self.client:
            self.client.close()
            self.client = None

    def load_skeleton(self, *args):
        """
        Read the current configuration from the server. Use the MEL generator
        to make the conversion on the fly. Loads the channel mapping from the
        Maya Mocap Device to the DAG node attributes. Also creates functions
        to generate the skeleton and marker set.
        """
        try:
            # Read the current configuration file directly of the
            # web server. Request MEL formatting.
            uri = "http://" + self.host + ":32080/?configuration=mel"
            fp = urllib2.urlopen(uri)

            # Read the MEL string and pass it to Maya for evaluation.
            mel.eval(fp.read())

            # Manually update the host definition function now if we are not
            # connected to the local host. Generate a MEL snippet here.
            if "127.0.0.1" != self.host:
                mel.eval(
                    "global proc string mDevice_server_hostname() "
                    + "{ return \"" + self.host + "\"; }")

            print(cmds.format(
                mDisplayString("kInfoLoad"),
                stringArg=self.host))

            return True
        except urllib2.URLError:
            cmds.warning(cmds.format(
                mDisplayString("kErrorLoad"),
                stringArg=self.host))

        return False

    def create_skeleton(self, *args):
        """
        Use the configuration supplied MEL commands to create the preview
        skeleton. This corresponds to the Mocap Device definitions.
        """
        if not self.load_skeleton(self, args):
            return False

        # Do we want to import center of mass locators?
        mel.eval(
            "global int $MDEVICE_IMPORT_MASS; $MDEVICE_IMPORT_MASS = "
            + str(self.mass) + ";")

        # Optionally load markers. Locator transforms with IK weights.
        group = mel.eval("mDevice_create_skeleton();")
        if self.marker:
            mel.eval("mDevice_create_marker();")

        cmds.select(group, replace=True)

        return True

    def start_device(self, *args):
        """
        Use the current channel mapping. Start the Maya Mocap Device and apply
        data from the server "unclutched" to the skeleton. Real time preview.
        """

        # Load the channel name mapping from the device server if it is not
        # already present.
        if not(self.have_device_definition()):
            if not self.load_skeleton(self, args):
                return False

        mel.eval("mDevice_device(1);")

        return True

    def stop_device(self, *args):
        """
        Remove the Maya Mocap Device. Stop real time preview.
        """
        if not(self.have_device_definition()):
            if not self.load_skeleton(self, args):
                return False

        mel.eval("mDevice_device(0);")

        return True

    def set_pose(self, *args):
        """
        Send the command to the server to set the zero pose. This might just
        mean that we want to re-zero the root position. Or, it might mean that
        we are creating a new marker set for a performer.
        """
        node = self.__lua_node()

        if self.pose_marker:
            rc, rs = node.set_pose_marker()
        else:
            rc, rs = node.set_pose()

        if not rc:
            cmds.warning(cmds.format(
                mDisplayString("kErrorPose"),
                stringArg=rs))

        return rc

    def start_record(self, *args):
        """
        Send the command to the server to start recording a take. This is not
        coupled to the preview at all.
        """
        node = self.__lua_node()

        rc, rs = node.start_take()
        if not rc:
            cmds.warning(cmds.format(
                mDisplayString("kErrorStartTake"),
                stringArg=rs))

        return rc

    def stop_record(self, *args):
        """
        Send the command to the server to stop recording a take.
        """
        node = self.__lua_node()

        rc, rs = node.stop_take()
        if not rc:
            cmds.warning(cmds.format(
                mDisplayString("kErrorStopTake"),
                stringArg=rs))

        return rc

    def import_take(self, *args):
        """
        Import a take. Use the current configuration group if it is available.
        Stop preview if it active.
        """
        # We can not load a take when the preview mode is active.
        if self.have_device_definition():
            self.stop_device(args)

        # Common options for the FBX export and the take importer.
        option = [
            "character=" + str(self.character),
            "marker=" + str(self.marker),
            "mass=" + str(self.mass)
        ]

        node = self.__lua_node()

        # Get the current take path name from the device server.
        rc, rs = node.get_take_path()
        if not rc:
            # No take loaded. Open a file dialog to find one. Does not require
            # that the take is loaded into the server state.
            rc, rs = node.get_data_path()
            if not rc or not rs:
                rs = ""

            list = cmds.fileDialog2(
                startingDirectory="/".join([rs.strip(), "take"]),
                fileFilter="*.mTake",
                fileMode=1)
            if list:
                rc = True
                rs = str(list[0])
            else:
                rc = False
                rs = None

        if not rc:
            cmds.warning(mDisplayString("kErrorTake"))
            return False

        # Remove whitespace. There is probably a newline at the end of
        # printed results from the device server.
        filename = ""
        if rs:
            filename = rs.strip()

        if self.fbx:
            # Replace the extension.
            for ext in ["mTake", "xml"]:
                if filename.endswith(ext):
                    filename = filename[0:len(filename) - len(ext)] + "fbx"
                    break

            # Export the take from the device server.
            rc, rs = node.export(filename, ",".join(option))
            if not rc:
                cmds.warning(cmds.format(
                    mDisplayString("kErrorTakeFBX"),
                    stringArg=rs))
        else:
            # Select the hierarchy of nodes if we have a group name.
            group = mel.eval("mDevice_group_name();")
            if cmds.objExists(group):
                cmds.select(
                    group,
                    replace=True,
                    hierarchy=True)

        if rc:
            # Import the file. May be using the take translator or the FBX
            # format.
            option = ";".join(option)
            print(cmds.format(
                mDisplayString("kInfoTake"),
                stringArg=(str(filename), str(option))))

            cmds.file(filename, i=True, options=option)

            # Sneaky MEL commands to set the current range of the time slider.
            cmd = ""
            if self.character and not self.fbx:
                cmd = "setPlaybackRangeToEnabledClips"
            else:
                cmd = "setPlaybackRangeToMinMax"

            # Range commands not documented. Make sure they are available in
            # MEL before running them.
            mel.eval("if (`exists(\"" + cmd + "\")`) { " + cmd + "(); }")

            return True

        return False

    def have_device_definition(self):
        """
        Returns true if the device channel mapping has been loaded.
        """
        if 1 == mel.eval("exists(\"mDevice_device_channel_list\");"):
            return True
        else:
            return False

    def create_rig(self, *args):
        from . import rig

        self.select_root_node()

        rig.track()

    def bake_rig(self, *args):
        from . import key

        self.select_root_node()

        key.bake()

    def add_contact(self, *args):
        from . import contact

        cp = contact.point()
        if cp.add(self.contact > 0):
            for hips in cp.hips_list:
                body = cmds.listRelatives(hips, parent=True, fullPath=True)
                cmds.mShadowCommand(str(body[0]))

    def shadow(self, *args):
        """
        Run the Shadow simulation on the current configuration group. Update
        the Hips.translate keyframes after editing contact points.
        """
        group = mel.eval("mDevice_group_name();")        
        if cmds.objExists(group):
            body_list = cmds.listRelatives(group,
                                           children=True,
                                           fullPath=True)
            for body in body_list:
                joint_list = cmds.listRelatives(body,
                                                children=True,
                                                fullPath=True,
                                                type="joint")
                if not joint_list:
                    continue

                cmds.mShadowCommand(str(body))

    def select_root_node(self, *args):
        """
        Select the all root nodes underneath the configuration group.

        ConfigurationGroup
        +-+-> Body
          +-+-> Hips
            +---> *
        """
        list = []

        group = mel.eval("mDevice_group_name();")
        if cmds.objExists(group):
            body_list = cmds.listRelatives(group,
                                           children=True,
                                           fullPath=True)
            if body_list:
                for body in body_list:
                    hip_list = cmds.listRelatives(body,
                                                  children=True,
                                                  fullPath=True,
                                                  type="joint")
                    if not hip_list:
                        continue

                    for hip in hip_list:
                        joint_list = cmds.listRelatives(hip,
                                                        children=True,
                                                        fullPath=True,
                                                        type="joint")
                        if not joint_list:
                            continue

                        list.append(hip)

        # Match up the current selection set with possible root  nodes. If one
        # is selected, use that. Otherwise, fall back on the full generated
        # list.
        selected = cmds.ls(selection=True, long=True)

        num_selected = 0
        cmds.select(clear=True)
        if selected:
            for node in selected:
                for item in list:
                    if node == item:
                        cmds.select(item, add=True)
                        num_selected = num_selected + 1

        # Nothing (or nothing valid) selected by the user. Replace with our
        # node look ups.
        if len(list) > 0 and 0 == num_selected:
            cmds.select(list, replace=True)

        return True

    def have_plugin(self):
        return ("" != self.plugin)

#
# END class action
#
