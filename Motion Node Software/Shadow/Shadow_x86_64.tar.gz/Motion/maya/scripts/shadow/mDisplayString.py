#
# @file    maya/scripts/shadow/mDisplayString.py
# @version 2.2
# @brief   Module wide internationalization. Provide strings in local
#          languages.
#
# (C) Copyright Motion Workshop 2015. All rights reserved.
#
# The coded instructions, statements, computer programs, and/or related
# material (collectively the "Data") in these files contain unpublished
# information proprietary to Motion Workshop, which is protected by
# US federal copyright law and by international treaties.
#
# The Data may not be disclosed or distributed to third parties, in whole
# or in part, without the prior written consent of Motion Workshop.
#
# The Data is provided "as is" without express or implied warranty, and
# with no claim as to its suitability for any purpose.
#

try:
    import maya
    maya.utils.loadStringResourcesForModule(__name__)
except ImportError:
    pass


def mDisplayString(name):
    return maya.stringTable["y_shadow_string.%s" % name]
