#
# @file    maya/scripts/shadow/displayString_res.py
# @version 2.2
# @brief   English localization resources.
#
# (C) Copyright Motion Workshop 2015. All rights reserved.
#
# The coded instructions, statements, computer programs, and/or related
# material (collectively the "Data") in these files contain unpublished
# information proprietary to Motion Workshop, which is protected by
# US federal copyright law and by international treaties.
#
# The Data may not be disclosed or distributed to third parties, in whole
# or in part, without the prior written consent of Motion Workshop.
#
# The Data is provided "as is" without express or implied warranty, and
# with no claim as to its suitability for any purpose.
#

from maya import stringTable

stringTable["y_shadow_string.kShadow"] = u"Shadow"
stringTable["y_shadow_string.kPreview"] = u"Preview"
stringTable["y_shadow_string.kLoadSkeleton"] = u"Load Skeleton"
stringTable["y_shadow_string.kLoadSkeletonAnnot"] = u"Read the current configuration from the device server. Create a skeleton."
stringTable["y_shadow_string.kMarkers"] = u"Markers"
stringTable["y_shadow_string.kMarkersAnnot"] = u"Create position markers for the skeleton with weight channels for FK/IK. Required for contact point editing."
stringTable["y_shadow_string.kStartPreview"] = u"Start Preview"
stringTable["y_shadow_string.kStartPreviewAnnot"] = u"Start streaming data from the from the device server."
stringTable["y_shadow_string.kStopPreview"] = u"Stop Preview"
stringTable["y_shadow_string.kStopPreviewAnnot"] = u"Stop streaming data from the from the device server."
stringTable["y_shadow_string.kSetPose"] = u"Set Pose"
stringTable["y_shadow_string.kSetPoseAnnot"] = u"Set the start pose on the device server. Initialize the skeleton position."
stringTable["y_shadow_string.kRestPose"] = u"Rest Pose"
stringTable["y_shadow_string.kRestPoseAnnot"] = u"Set the initial rest pose on the device server. Create the marker set based on the current device orientations."
stringTable["y_shadow_string.kStartTake"] = u"Start Take"
stringTable["y_shadow_string.kStartTakeAnnot"] = u"Start recording a take on the device server."
stringTable["y_shadow_string.kStopTake"] = u"Stop Take"
stringTable["y_shadow_string.kStopTakeAnnot"] = u"Stop recording a take on the device server."
stringTable["y_shadow_string.kImport"] = u"Import"
stringTable["y_shadow_string.kImportTake"] = u"Import Take"
stringTable["y_shadow_string.kImportTakeAnnot"] = u"Import the most recent take from the device server into the scene. Use the existing skeleton."
stringTable["y_shadow_string.kUseCharacter"] = u"Use Character"
stringTable["y_shadow_string.kUseCharacterAnnot"] = "Import animation as a clip in the Trax editor. Append new clips at the end of the track."
stringTable["y_shadow_string.kUseFBX"] = u"Use FBX"
stringTable["y_shadow_string.kUseFBXAnnot"] = u"Import take data using the FBX format. For systems that do not have the take import plug-in."
stringTable["y_shadow_string.kEdit"] = u"Edit"
stringTable["y_shadow_string.kCreateRig"] = u"Create Rig"
stringTable["y_shadow_string.kCreateRigAnnot"] = u"Rig an animated skeleton for effector contact point editing."
stringTable["y_shadow_string.kBakeRig"] = u"Bake Rig"
stringTable["y_shadow_string.kBakeRigAnnot"] = u"Bake the skeleton root translation including edited contact points."
stringTable["y_shadow_string.kAddContact"] = u"Add Contact"
stringTable["y_shadow_string.kAddContactAnnot"] = u"Select a joint and a region of the time slider to create a new contact point."
stringTable["y_shadow_string.kReplaceExisting"] = u"Replace Existing"
stringTable["y_shadow_string.kReplaceExistingAnnot"] = u"New contact points replace all existing contacts in the selected time slider range."
stringTable["y_shadow_string.kPreference"] = u"Settings"
stringTable["y_shadow_string.kAddress"] = u"Address"
stringTable["y_shadow_string.kHUDPreview"] = u"Preview"
stringTable["y_shadow_string.kHUDRecording"] = u"Recording"
stringTable["y_shadow_string.kInfoConnect"] = u"Connected to device server at \"^1s\""
stringTable["y_shadow_string.kInfoLoad"] = u"Loaded configuration from device server at \"^1s\""
stringTable["y_shadow_string.kInfoTake"] = u"Importing take from \"^1s\" with options=\"^2s\""
stringTable["y_shadow_string.kErrorConnect"] = u"Failed to connect device server at \"^1s\""
stringTable["y_shadow_string.kErrorLoad"] = u"Failed to read configuration from device server at \"^1s\""
stringTable["y_shadow_string.kErrorPose"] = u"Device server failed to set pose: ^1s"
stringTable["y_shadow_string.kErrorStartTake"] = u"Device server failed to start recording: ^1s"
stringTable["y_shadow_string.kErrorStopTake"] = u"Device server failed to stop recording: ^1s"
stringTable["y_shadow_string.kErrorTake"] = u"Device server does not have an active take. Load or record one to import."
stringTable["y_shadow_string.kErrorTakeFBX"] = u"Device server failed to export take to FBX: ^1s"

stringTable["y_shadow_string.kInfoAddContact"] = u"Added contact point from ^1s to ^2s for \"^3s\""

stringTable["y_shadow_string.kErrorTimeRange"] = u"No timeline range selected. Hold shift and drag in the time slider to select a range."
stringTable["y_shadow_string.kErrorSelectNode"] = u"No transform node selected. Select at least one joint or marker node."
stringTable["y_shadow_string.kErrorShadowNode"] = u"Plug not connected to a mShadowNode effector for node \"^1s\". Unable to create contact point."
stringTable["y_shadow_string.kErrorAnimCurve"] = u"Animation curve on plug \"^1s\" does not exist"
stringTable["y_shadow_string.kErrorKeyFrame"] = u"Failed to set key frame at ^1s on ^2s to ^3s"

stringTable["y_shadow_string.kErrorSelectRoot"] = u"Must select one at least one joint node. Select the root of a skeleton hierarchy."
stringTable["y_shadow_string.kErrorConnected"] = u"Joint node \"^1s\" already connected to \"^2s\" rig."
stringTable["y_shadow_string.kErrorAnimation"] = u"No animation curve attached to \"^1s\". Unable to connect rig input for this plug."
