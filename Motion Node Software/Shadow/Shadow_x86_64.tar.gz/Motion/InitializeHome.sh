#!/bin/sh
#
# Create a directory tree in the current user's HOME with the distribution data
# files. Prepare to run the Motion Service with the data path set to
# $HOME/Motion.
#
# @file    InitializeHome.sh
# @author  Luke Tokheim, luke@motionnode.com
# @version 2.0
#

# Optional command line argument. Default to the HOME environment variable.
if [ $# -gt 0 ]; then
  TARGET=$1
elif [ "$MOTION_HOME" != "" ]; then
  TARGET=$MOTION_HOME
else
  TARGET=$HOME
fi

echo Creating user data folder in \"$TARGET\"

INSTALL=/usr/bin/install
INSTALL_NAME=Motion

$INSTALL -d $TARGET/$INSTALL_NAME
$INSTALL -d $TARGET/$INSTALL_NAME/default
$INSTALL -d $TARGET/$INSTALL_NAME/take

for file in database.db export_c3d.xml scene.fbx user.xml
do
  dist="$file-dist"
  if [ -f $dist ]; then
    $INSTALL --mode=644 --backup "$dist" "$TARGET/$INSTALL_NAME/default/$file"
  fi
done

