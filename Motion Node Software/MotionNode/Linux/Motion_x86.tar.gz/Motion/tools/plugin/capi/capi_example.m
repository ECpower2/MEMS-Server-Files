function [data] = capi_example(n, type),
% capi_example Example function for the Motion C API library.
%
%   [data] = capi_example(n, type)
%
%   Connect to a real-time data stream, read n samples, and return them
%   in a matrix.
%
%   Use the type parameter to select the Preview (1), Sensor (2), or
%   Raw (3) stream.
%
%   Copyright 2013 Motion Workshop
%   http://www.motionnode.com/
%

  % Number of samples.
  if nargin <= 0,
    n = 1000;
  end
  
  % Stream type.
  if nargin <= 1,
    type = 1;
  end

  % Load the DLL. This can also be done once per session.
  if not(libisloaded('mncapi')),
    loadlibrary 'MotionCAPI' 'MotionCAPI' alias 'mncapi';
  end
  
  [result,data] = mncapi_lua_chunk_host('127.0.0.1', 'print("Hello World")', zeros(1,1024));
  sprintf('%s', data)
  
  % Open data stream.
  handle = mncapi_open(type);

  % Read N samples. Copy the Euler angles into the data buffer.
  data = [];
  for i=[1:n],
    [result, sample] = mncapi_sample(handle, zeros(1,14));
    if not(result),
      error('failed to read sample');
    end
    
    % Select output by stream type.
    if 1 == type,
      % Preview, copy Euler angles.
      %data(end+1,:) = rad2deg(sample([9:11]));
    else
      % Sensor, copy accelerometer, magmetometer, and
      % gyroscope channels.
      %data(end+1,:) = sample([1:9]);
    end
  end
  
  % Close data stream.
  mncapi_close(handle);

  % Load the DLL.
  unloadlibrary('mncapi');
end

function [handle] = mncapi_open(type)
  handle = calllib('mncapi', 'mncapi_open', int32(type));
end

function mncapi_close(handle)
  calllib('mncapi', 'mncapi_close', int32(handle));
end

function [result,data] = mncapi_sample(handle, data)
  [result,data] = calllib('mncapi', 'mncapi_sample', int32(handle), data, int32(length(data)));
end

function [result,data] = mncapi_lua_chunk_host(host, chunk, data)
  [result,data] = calllib('mncapi', 'mncapi_lua_chunk_host', string(host), string(chunk), string(data), int32(length(data)));
end

