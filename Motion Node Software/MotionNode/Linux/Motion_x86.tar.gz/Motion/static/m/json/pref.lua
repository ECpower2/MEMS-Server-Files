local base = _G

local state = {
  ["track_mode"] = 19,
  ["export_type"] = "fbx",
  ["euler_order"] = "xyz"
}

for key, value in pairs(state) do
  sv = node.system.get_default(key)
  if "" ~= sv then
    state[key] = node.system.get_default(key)

    -- Cast to number format.
    if base.type(1) == base.type(value) then
      state[key] = base.tonumber(state[key])
    end
  end
end

return node.json.encode(state)