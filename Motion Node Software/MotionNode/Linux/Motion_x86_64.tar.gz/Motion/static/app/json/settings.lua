--
-- Return a string JSON description of the user settings on the Motion Service. 
-- Show the active location, the current ractor, and any system preferences that
-- we may want to view.
--
-- @file    json/settings.lua
-- @version 2.2
--
local base = _G

local settings = {
  ['location'] = {},
  ['ractor'] = {},
  ['system'] = {
    ['export_type'] = 'fbx',
    ['auto_export'] = 0,
    ['auto_export_path'] = '{path}/take.fbx'
  },
  ['export_types'] = {}
}

local location_to_table = function(obj)
  return {
    ['key'] = obj['key'],
    ['name'] = obj['name'],
    ['active'] = obj['active'],
    ['canonical_address'] = obj['canonical_address'],
    ['latitude'] = obj['latitude'],
    ['longitude'] = obj['longitude'],
    ['elevation'] = obj['elevation']
  }
end

local ractor_to_table = function(obj)
  return {
    ['name'] = obj['name'],
    ['active'] = obj['active'],
    ['key'] = obj['key'],
    ['measurement'] = {
      ['unit'] = 'cm',
      ['height'] = obj.height,
      ['arm'] = obj.arm,
      ['leg'] = obj.leg
    }
  }
end

-- Location.
local list = node.system.get_location_list()
if list then
  for _, item in ipairs(list:list()) do
    table.insert(settings.location, location_to_table(item))
  end
else
  --local preference = node.system.get_preference()
  --if preference then
  --  result = result .. location_node_to_xml(null, preference.address_canonical, preference.latitude, preference.longitude, preference.elevation, 1, null)  
  --end
end

-- Ractor.
local list = node.system.get_ractor_list()
if list then
  for _, item in ipairs(list:list()) do
    table.insert(settings.ractor, ractor_to_table(item))
  end
end

-- System preferences.
for key, value in pairs(settings.system) do
  sv = node.system.get_default(key)
  if "" ~= sv then
    settings.system[key] = sv

    -- Cast to number format.
    if base.type(1) == base.type(value) then
      settings.system[key] = base.tonumber(settings.system[key])
    end
  end
end

-- List of available export types.
local list = node.system.export_type()
if list then
  for key, value in pairs(list) do
    table.insert(settings.export_types, {
      ['key'] = key,
      ['name'] = value['description']
      --settings.export_types[key] = value
    })
  end
end

return node.json.encode(settings)