local base = _G

local is_taking = node.is_taking()
local is_reading = is_taking or node.is_reading()
local is_connected = is_reading or node.is_connected()
local is_configured = is_connected or node.is_configured()
local is_tracking = node.is_tracking()

local state = {
  ['is_configured'] = is_configured,
  ['is_connected'] = is_connected,
  ['is_reading'] = is_reading,
  ['is_taking'] = is_taking,
  ['is_tracking'] = is_tracking,
  ['status'] = 'Unknown device status.'
}

--
-- Status message. Like the Motion Monitor tray notification.
--
if not is_configured then
  state.status = "Empty configuration, 0 devices available."
else
  local num_node = 0
  
  if is_taking then
    state.status = "Recording from "
    num_node = node.num_reading(true)
  elseif is_reading then
    state.status = "Reading from "
    num_node = node.num_reading(true)
  else
    state.status = "Connected to "
    num_node = node.num_connected(true)
  end

  state.status = state.status .. num_node .. " device"
  if 1 == num_node then
    state.status = state.status .. "."
  else
    state.status = state.status .. "s."
  end
end


return node.json.encode(state)