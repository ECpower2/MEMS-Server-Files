--
-- Return an string XML description of the current state of the Motion Service.
-- The state tree provides all information that the main User Interface view
-- needs to control and configure the sensor modules.
--
-- @file    static/index.lua
-- @version 2.2
--

-- 
local result = "<?xml version=\"1.0\"?>"
local root_name = "state"


if not node.system.is_initialized() then
  -- The system has not been initialized yet, i.e. no
  -- "initialize.lua" file has been loaded with the site
  -- specific preferences. Print the current preference
  -- values so the user can edit them and generate the
  -- "initialize.lua" file.
  root_name = "initialize"

  local preference = node.system.get_preference()
  local valid = false
  if (string.len(preference.address_canonical) > 0) and (string.len(preference.data_path) > 0) then
    valid = true
  end

  if (preference.valid_location == true) and (string.len(preference.data_path) > 0) then
    valid = true
  end


  result = result ..
    "<" .. root_name
  result = result ..  
    " valid=\"" .. node.xml.encode_attribute(valid) .. "\">" ..
    "<address>" ..
    "<input>" .. node.xml.encode_string(preference.address_input) .. "</input>" ..
    "<canonical>" .. node.xml.encode_string(preference.address_canonical) .. "</canonical>" ..
    "</address>" ..
    "<data_path>" .. node.xml.encode_string(preference.data_path) .. "</data_path>" ..
    "<location>" .. 
    "<latitude>" .. node.xml.encode_string(preference.latitude) .. "</latitude>" ..
    "<longitude>" .. node.xml.encode_string(preference.longitude) .. "</longitude>" ..
    "<elevation>" .. node.xml.encode_string(preference.elevation) .. "</elevation>" ..
    "</location>" ..
    "<log_path>" .. node.xml.encode_string(preference.log_path) .. "</log_path>"
else
  
  function configuration_node_to_xml(configured_node, open_tag, close_tag, is_connected, is_reading, detail)
    if close_tag then
      close_tag = "/"
    else
      close_tag = ""
    end
    
    if open_tag then
      open_tag = "<node"
    else
      open_tag = ""
    end
    
    local show_detail = false
    if detail and configured_node.id == detail then
      show_detail = true
    end

    local optional = ""

    if show_detail or not configured_node.active then
      optional = optional .. " active=\"" .. node.xml.encode_attribute(configured_node.active) .. "\""
    end
    if show_detail or configured_node.bus then
      optional = optional .. " bus=\"" .. node.xml.encode_attribute(configured_node.bus) .. "\""
    end
    if show_detail or configured_node.parent and string.len(configured_node.parent) > 0 then
      optional = optional .. " parent=\"" .. node.xml.encode_attribute(configured_node.parent) .. "\""
    end
    if show_detail or configured_node.gain_sensor < 1 then
      optional = optional .. " gain_sensor=\"" .. node.xml.encode_attribute(configured_node.gain_sensor) .. "\""
    end
    if show_detail or configured_node.track_gyroscope_bias < 1 then
      optional = optional .. " track_gyroscope_bias=\"" .. node.xml.encode_attribute(configured_node.track_gyroscope_bias) .. "\""
    end
    if show_detail or configured_node.pipeline_select ~= 0 then
      optional = optional .. " pipeline_select=\"" .. node.xml.encode_attribute(configured_node.pipeline_select) .. "\""
    end
    if configured_node.node_version ~= 0 then
      optional = optional .. " node_version=\"" .. node.xml.encode_attribute(configured_node.node_version) .. "\""
    end
    if configured_node.uuid and string.len(configured_node.uuid) > 0 then
      optional = optional .. " uuid=\"" .. node.xml.encode_attribute(configured_node.uuid) .. "\""
    end

    return
      open_tag ..
      " key=\"" .. node.xml.encode_attribute(configured_node.key) .. "\"" ..
      " id=\"" .. node.xml.encode_attribute(configured_node.id) .. "\"" ..
      " name=\"" .. node.xml.encode_attribute(configured_node.name) .. "\"" ..
      " source=\"" .. node.xml.encode_attribute(configured_node.source) .. "\"" ..
      " gain=\"" .. node.xml.encode_attribute(configured_node.gain) .. "\"" ..
      " gselect=\"" .. node.xml.encode_attribute(configured_node.gselect) .. "\"" ..
      optional ..
      " connected=\"" .. node.xml.encode_attribute(is_connected or node.is_connected(configured_node.id)) .. "\"" ..
      " reading=\"" .. node.xml.encode_attribute(is_reading or node.is_reading(configured_node.id)) .. "\"" .. 
      close_tag ..
      ">"
  end
  
  function configuration_tree_to_info(configured_node)
    local result = 0
    for _,child_node in pairs(configured_node:list()) do
      result = result + 1
    end
    
    return result
  end

  function configuration_tree_to_xml(configured_node, is_connected, is_reading, detail)
    local result = configuration_node_to_xml(configured_node.value, true, false, is_connected, is_reading, detail)
    
    for _,child_node in pairs(configured_node:list()) do
      result = result .. configuration_tree_to_xml(child_node, is_connected, is_reading, detail)
    end
 
    result = result .. "</node>"
    
    return result
  end
  
  local is_taking = node.is_taking()
  local is_reading = is_taking or node.is_reading()
  local is_connected = is_reading or node.is_connected()
  local is_configured = is_connected or node.is_configured()
  local is_tracking = node.is_tracking()
  
  local optional = ""
  if is_tracking then
    optional = optional .. " tracking=\"" .. node.xml.encode_attribute(is_tracking) .. "\""
  end

  -- Create a summary of the configuration state in the root node.
  result = result ..
    "<" .. root_name ..
    " configured=\"" .. node.xml.encode_attribute(is_configured) .. "\"" ..
    " connected=\"" .. node.xml.encode_attribute(is_connected) .. "\"" ..
    " reading=\"" .. node.xml.encode_attribute(is_reading) .. "\"" ..
    " taking=\"" .. node.xml.encode_attribute(is_taking) .. "\"" ..
    optional ..
    ">"
  
  local node_detail
  if HTTP_REQUEST and HTTP_REQUEST['detail'] then
    if 'default' == HTTP_REQUEST['detail'] or node.is_configured(HTTP_REQUEST['detail']) then
	    node_detail = HTTP_REQUEST['detail']
	  end
  end

  --
  -- Print a tree version of the configuration if possible.
  -- This will order the nodes by the hierarchy rather than
  -- by source name or by id field.
  --
  local default_node = node.get_node_default()
  if default_node and node_detail and node_detail == default_node.id then
  
    result = result .. "<configuration detail=\"" ..
      node.xml.encode_attribute(node_detail) .. "\">" ..
      configuration_node_to_xml(default_node, true, true, false, false, node_detail)
    result = result .. "</configuration>"
  
  else
  
    local configured_node = node.configuration_tree()
    if configured_node then
      result = result .. "<configuration"
      if node_detail then
        result = result .. " detail=\"" .. node.xml.encode_attribute(node_detail) .. "\""
      end
      result = result .. ">"
      for _,child_node in pairs(configured_node:list()) do
        result = result .. configuration_tree_to_xml(child_node, is_connected, is_reading, node_detail)
      end
      result = result .. "</configuration>"
    else

      -- The current configuration state. Print the current status of each
      -- configured Node.
      local container = node.configuration()
      if container then
        result = result .. "<configuration"
        if node_detail then
          result = result .. " detail=\"" .. node.xml.encode_attribute(node_detail) .. "\""
        end
        
        local configured_node
        for _,configured_node in pairs(container:list()) do
          result = result .. configuration_node_to_xml(configured_node, true, true, is_connected, is_reading, node_detail)
        end
        result = result .. "</configuration>"
      end

    end
  
  end -- Default node detail mode


  local preference = node.system.get_preference()
  if preference then
    result = result ..
      "<data_path>" .. node.xml.encode_string(preference.data_path) .. "</data_path>" .. 
      "<log_path>" .. node.xml.encode_string(preference.log_path) .. "</log_path>"
  end
  
  result = result .. node.xml.take_to_xml()

end -- if not node.is_initialized() else


--
-- Shared nodes. 
--
result = result .. node.xml.history_to_xml()

result = result .. "</" .. root_name .. ">"

return result
