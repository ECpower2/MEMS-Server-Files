--
-- Return an string JSON description of the current state of
-- the Motion Service. The state tree provides all information
-- that the User Interface view needs to control and configure
-- the sensor modules.
--
-- @file    static/m/json/index.lua
-- @version 2.0
--

local base = _G
local result = "{"

local state = {
  ['configured'] = false,
  ['connected'] = false,
  ['reading'] = false,
  ['taking'] = false,
  ['node'] = {},
  ['version'] = node._VERSION,
  ['bus'] = node._BUS,
  ['data_path'] = '',
  ['log_path'] = '',
  ['take'] = {},
  ['history'] = {},
  ['status'] = 'Unknown device status.'
}

function configuration_node_to_json(configured_node, open_tag, close_tag, is_connected, is_reading, detail)    
  local show_detail = false
  if detail and configured_node.id == detail then
    show_detail = true
  end
    
  local node_state = {
    ['key'] = configured_node.key,
    ['id'] = configured_node.id,
    ['name'] = configured_node.name,
    ['source'] = configured_node.source,
    ['gain'] = configured_node.gain,
    ['gselect'] = configured_node.gselect,
    ['gain_sensor'] = configured_node.gain_sensor,
    ['track_gyroscope_bias'] = configured_node.track_gyroscope_bias,
    ['pipeline_select'] = configured_node.pipeline_select,
    ['connected'] = is_connected or node.is_connected(configured_node.id),
    ['reading'] = is_reading or node.is_reading(configured_node.id),
    ['node'] = {}
  }

  local optional = ""
    
  if configured_node.node_version >= 3 then
    -- Hardware version 3 does not have selectable sample rate. Fix it at 100 Hz.
    optional = optional .. " sample_rate=\"" .. node.xml.encode_attribute(100) .. "\""
  elseif show_detail or (configured_node.delay and configured_node.delay > 0) then
    optional = optional .. " delay=\"" .. node.xml.encode_attribute(configured_node.delay) .. "\""
    optional = optional .. " sample_rate=\"" .. node.xml.encode_attribute(node.delay_to_sample_rate(configured_node.delay)) .. "\""
  end    
  if show_detail or not configured_node.active then
    optional = optional .. " active=\"" .. node.xml.encode_attribute(configured_node.active) .. "\""
  end
  if show_detail or configured_node.bus then
    optional = optional .. " bus=\"" .. node.xml.encode_attribute(configured_node.bus) .. "\""
  end
  if show_detail or configured_node.parent and string.len(configured_node.parent) > 0 then
    optional = optional .. " parent=\"" .. node.xml.encode_attribute(configured_node.parent) .. "\""
  end
  if show_detail or configured_node.gain_sensor < 1 then
    optional = optional .. " gain_sensor=\"" .. node.xml.encode_attribute(configured_node.gain_sensor) .. "\""
  end
  if show_detail or configured_node.track_gyroscope_bias < 1 then
    optional = optional .. " track_gyroscope_bias=\"" .. node.xml.encode_attribute(configured_node.track_gyroscope_bias) .. "\""
  end
  if show_detail or configured_node.pipeline_select ~= 0 then
    optional = optional .. " pipeline_select=\"" .. node.xml.encode_attribute(configured_node.pipeline_select) .. "\""
  end
  if configured_node.node_version ~= 0 then
    optional = optional .. " node_version=\"" .. node.xml.encode_attribute(configured_node.node_version) .. "\""
  end

  return node_state
end

function configuration_tree_to_json(configured_node, is_connected, is_reading, detail)
  local result = configuration_node_to_json(configured_node.value, true, false, is_connected, is_reading, detail)
    
  for _,child_node in pairs(configured_node:list()) do
    table.insert(result.node, configuration_tree_to_json(child_node, is_connected, is_reading, detail))
  end

  return result
end
  
local is_taking = node.is_taking()
local is_reading = is_taking or node.is_reading()
local is_connected = is_reading or node.is_connected()
local is_configured = is_connected or node.is_configured() 

-- Create a summary of the configuration state in the root node.
state.configured = is_configured
state.connected = is_connected
state.reading = is_reading
state.taking = is_taking

--
-- Node tree. Not necessary for the mobile view.
--
if false then
  local configured_node = node.configuration_tree()
  if configured_node then
    for _,child_node in pairs(configured_node:list()) do
      local node_state = configuration_tree_to_json(child_node, is_connected, is_reading, node_detail)
      if node_state then
        table.insert(state.node, node_state)
      end     
    end
  end
end

--
-- Some system settings.
--
local preference = node.system.get_preference()
if preference then
  state.data_path = preference.data_path
  state.log_path = preference.log_path
end

--
-- Current take information.
--
local take = node.take()
if take then
  state.take.name = take.name
  state.take.description = take.description
  state.take.loaded_from = take.loaded_from
end

--
-- User history. 
--
local history = node.system.get_history()
if history then
  local key, value
  for key,value in pairs(history) do
    state.history[key] = value
  end
end

--
-- Status message. Like the Motion Monitor tray notification.
--
if not is_configured then
  state.status = "Empty configuration, 0 devices available."
else
  local num_node = 0
  
  if is_taking then
    state.status = "Recording from "
    num_node = node.num_reading(true)
  elseif is_reading then
    state.status = "Reading from "
    num_node = node.num_reading(true)
  else
    state.status = "Connected to "
    num_node = node.num_connected(true)
  end

  state.status = state.status .. num_node .. " device"
  if 1 == num_node then
    state.status = state.status .. "."
  else
    state.status = state.status .. "s."
  end
end


result = node.json.encode(state)

return result
