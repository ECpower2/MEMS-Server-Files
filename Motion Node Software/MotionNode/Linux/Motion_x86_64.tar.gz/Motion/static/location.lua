--
-- Return an string XML description of the current geographic location of the
-- Motion Service. Same format as the online geocoder at:
--   http://www.motionnode.com/geocode/
--
-- @file    static/location.lua
-- @version 2.0
--

-- Utility function. Generate a location XML snippet based on input parameters.
local function location_node_to_xml(name, address, latitude, longitude, elevation, active, key)
  local result = "<location"
  if key then
    result = result .. " key=\"" .. node.xml.encode_attribute(key) .. "\""
  end
  if active then
    result = result .. " active=\"" .. node.xml.encode_attribute(active) .. "\""
  end
  
  result = result .. ">"
  
  if name then
    result = result .. "<name>" .. node.xml.encode_string(name) .. "</name>"
  end
  
  result = result ..
    "<address>" .. node.xml.encode_string(address) .. "</address>" ..
    "<point>" ..
    "<latitude>" .. node.xml.encode_string(latitude) .. "</latitude>" ..
    "<longitude>" .. node.xml.encode_string(longitude) .. "</longitude>" ..
    "<elevation unit=\"meter\">" .. node.xml.encode_string(elevation) .. "</elevation>" ..
    "</point>"

  result = result .. "</location>"

  return result
end

local result =
  "<?xml version=\"1.0\"?>" ..
  "<geocode>"

local location_list = node.system.get_location_list()
if location_list then
  for _,location in ipairs(location_list:list()) do
    result = result .. location_node_to_xml(location.name, location.canonical_address, location.latitude, location.longitude, location.elevation, location.active, location.key)
  end
else
  local preference = node.system.get_preference()
  if preference then
    result = result .. location_node_to_xml(null, preference.address_canonical, preference.latitude, preference.longitude, preference.elevation, 1, null)  
  end
end

result = result .. "</geocode>"

return result
